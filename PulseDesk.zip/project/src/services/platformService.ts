// Real Platform Integration Service with OAuth2 and API connections
import { auth } from '../firebase';
import { signOut } from 'firebase/auth';

export interface Message {
  id: string;
  platform: 'gmail' | 'slack' | 'telegram';
  sender: string;
  subject?: string;
  content: string;
  timestamp: Date;
  emotion?: string;
  confidence?: number;
  priority?: 'low' | 'medium' | 'high' | 'urgent';
  rawData?: any;
}

export interface PlatformConnection {
  platform: 'gmail' | 'slack' | 'telegram';
  connected: boolean;
  accessToken?: string;
  refreshToken?: string;
  apiKey?: string;
  webhookUrl?: string;
  botToken?: string;
  lastSync?: Date;
  messageCount: number;
  userInfo?: any;
}

class PlatformService {
  private connections: Map<string, PlatformConnection> = new Map();
  private messages: Message[] = [];
  private syncIntervals: Map<string, NodeJS.Timeout> = new Map();

  // Real OAuth2 Configuration
  private readonly OAUTH_CONFIG = {
    gmail: {
      clientId: import.meta.env.VITE_GMAIL_CLIENT_ID || 'demo-gmail-client-id',
      redirectUri: `${window.location.origin}/auth/gmail/callback`,
      scopes: [
        'https://www.googleapis.com/auth/gmail.readonly',
        'https://www.googleapis.com/auth/userinfo.email',
        'https://www.googleapis.com/auth/userinfo.profile',
        'openid'
      ]
    },
    slack: {
      clientId: import.meta.env.VITE_SLACK_CLIENT_ID || 'demo-slack-client-id',
      redirectUri: `${window.location.origin}/auth/slack/callback`,
      scopes: [
        'channels:read',
        'channels:history',
        'chat:write',
        'users:read'
      ]
    },
    telegram: {
      webhookUrl: import.meta.env.VITE_TELEGRAM_WEBHOOK_URL || `${window.location.origin}/api/telegram/webhook`
    }
  };

  constructor() {
    this.loadPersistedData();
    this.setupMessageListener();
  }

  // Setup message listener for OAuth callbacks
  private setupMessageListener() {
    window.addEventListener('message', (event) => {
      if (event.origin !== window.location.origin) return;
      
      if (event.data.type === 'GMAIL_AUTH_SUCCESS') {
        this.handleGmailAuthSuccess(event.data.code);
      } else if (event.data.type === 'SLACK_AUTH_SUCCESS') {
        this.handleSlackAuthSuccess(event.data.code);
      } else if (event.data.type === 'AUTH_ERROR') {
        console.error('OAuth Error:', event.data.error);
        throw new Error(`Authentication failed: ${event.data.error}`);
      }
    });
  }

  // Advanced emotion analysis engine
  private analyzeEmotion(text: string): { emotion: string; confidence: number; priority: string } {
    const content = text.toLowerCase();
    
    const emotionPatterns = {
      angry: {
        keywords: ['angry', 'furious', 'mad', 'rage', 'hate', 'disgusted', 'outraged', 'livid', 'pissed', 'frustrated', 'annoyed', 'irritated', 'unacceptable', 'terrible', 'awful', 'worst', 'horrible', 'disgusting', 'pathetic'],
        intensity: 0.9
      },
      frustrated: {
        keywords: ['frustrated', 'annoying', 'irritating', 'disappointing', 'useless', 'broken', 'not working', 'failed', 'error', 'problem', 'issue', 'trouble', 'difficult', 'complicated', 'confusing'],
        intensity: 0.7
      },
      confused: {
        keywords: ['confused', 'unclear', 'don\'t understand', 'how to', 'help me', 'explain', 'what does', 'not sure', 'uncertain', 'puzzled', 'lost', 'complicated', 'difficult to understand'],
        intensity: 0.6
      },
      sad: {
        keywords: ['sad', 'disappointed', 'upset', 'unhappy', 'depressed', 'down', 'heartbroken', 'devastated', 'let down', 'discouraged'],
        intensity: 0.7
      },
      happy: {
        keywords: ['happy', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 'awesome', 'perfect', 'love', 'thank you', 'thanks', 'appreciate', 'satisfied', 'pleased', 'delighted', 'thrilled', 'brilliant', 'outstanding'],
        intensity: 0.8
      },
      excited: {
        keywords: ['excited', 'thrilled', 'amazing', 'incredible', 'fantastic', 'awesome', 'can\'t wait', 'looking forward', 'eager', 'enthusiastic'],
        intensity: 0.8
      }
    };

    let bestMatch = { emotion: 'neutral', confidence: 0.5, priority: 'low' };
    
    for (const [emotion, pattern] of Object.entries(emotionPatterns)) {
      const matches = pattern.keywords.filter(keyword => content.includes(keyword)).length;
      if (matches > 0) {
        const confidence = Math.min(0.95, (matches / pattern.keywords.length) * pattern.intensity + 0.3);
        if (confidence > bestMatch.confidence) {
          bestMatch = {
            emotion,
            confidence,
            priority: this.calculatePriority(emotion, confidence)
          };
        }
      }
    }

    return bestMatch;
  }

  private calculatePriority(emotion: string, confidence: number): string {
    if (emotion === 'angry' && confidence > 0.7) return 'urgent';
    if ((emotion === 'frustrated' || emotion === 'angry') && confidence > 0.5) return 'high';
    if (emotion === 'confused' || emotion === 'sad') return 'medium';
    return 'low';
  }

  // GMAIL REAL INTEGRATION
  async connectGmail(): Promise<void> {
    try {
      console.log('🔗 Starting real Gmail OAuth2 integration...');
      
      // Check if real OAuth credentials are configured
      if (import.meta.env.VITE_GMAIL_CLIENT_ID && import.meta.env.VITE_GMAIL_CLIENT_ID !== 'demo-gmail-client-id') {
        // Use real OAuth flow
        await this.performRealGmailOAuth();
      } else {
        // Use demo flow with user confirmation
        await this.performDemoGmailConnection();
      }
    } catch (error) {
      console.error('❌ Gmail OAuth failed:', error);
      throw error;
    }
  }

  private async performRealGmailOAuth(): Promise<void> {
    // Build OAuth2 URL
    const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
    authUrl.searchParams.set('client_id', this.OAUTH_CONFIG.gmail.clientId);
    authUrl.searchParams.set('redirect_uri', this.OAUTH_CONFIG.gmail.redirectUri);
    authUrl.searchParams.set('response_type', 'code');
    authUrl.searchParams.set('scope', this.OAUTH_CONFIG.gmail.scopes.join(' '));
    authUrl.searchParams.set('access_type', 'offline');
    authUrl.searchParams.set('prompt', 'consent');
    authUrl.searchParams.set('state', 'gmail_auth');

    // Open OAuth popup
    const popup = window.open(
      authUrl.toString(),
      'gmail_oauth',
      'width=500,height=600,scrollbars=yes,resizable=yes'
    );

    if (!popup) {
      throw new Error('Popup blocked. Please allow popups for this site.');
    }

    // Wait for OAuth completion
    return new Promise((resolve, reject) => {
      const checkClosed = setInterval(() => {
        if (popup.closed) {
          clearInterval(checkClosed);
          reject(new Error('OAuth window was closed by user'));
        }
      }, 1000);

      // Listen for success message
      const messageHandler = (event: MessageEvent) => {
        if (event.data.type === 'GMAIL_AUTH_SUCCESS') {
          clearInterval(checkClosed);
          popup.close();
          window.removeEventListener('message', messageHandler);
          resolve();
        } else if (event.data.type === 'AUTH_ERROR') {
          clearInterval(checkClosed);
          popup.close();
          window.removeEventListener('message', messageHandler);
          reject(new Error(event.data.error));
        }
      };

      window.addEventListener('message', messageHandler);
    });
  }

  private async performDemoGmailConnection(): Promise<void> {
    // Show demo connection dialog
    const userEmail = prompt(
      '📧 Gmail Demo Integration\n\n' +
      'Since real OAuth credentials are not configured, we\'ll simulate the connection.\n\n' +
      'In production, this would:\n' +
      '• Open Google OAuth popup\n' +
      '• Request Gmail read permissions\n' +
      '• Fetch your actual emails\n' +
      '• Analyze real message emotions\n\n' +
      'Enter your email to simulate connection:'
    );

    if (!userEmail) {
      throw new Error('Email is required for Gmail connection');
    }

    if (!userEmail.includes('@')) {
      throw new Error('Please enter a valid email address');
    }

    // Simulate OAuth success
    await this.simulateGmailConnection(userEmail);
  }

  private async simulateGmailConnection(email: string): Promise<void> {
    // Store simulated connection
    this.connections.set('gmail', {
      platform: 'gmail',
      connected: true,
      accessToken: 'demo-access-token',
      refreshToken: 'demo-refresh-token',
      lastSync: new Date(),
      messageCount: 0,
      userInfo: { email, name: email.split('@')[0] }
    });

    console.log('✅ Gmail demo connection established for:', email);
    
    // Generate demo messages
    await this.generateDemoGmailMessages(email);
    this.startSyncForPlatform('gmail');
    this.saveToStorage();
    
    // Trigger update event for dashboard components
    this.notifyConnectionUpdate();
  }

  private async generateDemoGmailMessages(userEmail: string): Promise<void> {
    const demoMessages = [
      {
        from: 'support@company.com',
        subject: 'Thank you for your purchase!',
        content: 'We are thrilled to have you as a customer. Your order has been processed successfully and will be shipped soon. Thank you for choosing us!',
        emotion: 'happy'
      },
      {
        from: 'billing@service.com',
        subject: 'Payment Issue - Action Required',
        content: 'We encountered an issue processing your payment. This is frustrating and we need you to update your payment method immediately to avoid service interruption.',
        emotion: 'frustrated'
      },
      {
        from: 'help@platform.com',
        subject: 'How to use new features?',
        content: 'I am confused about how to use the new dashboard features. Can you please explain how the analytics section works? I don\'t understand the interface.',
        emotion: 'confused'
      },
      {
        from: 'feedback@app.com',
        subject: 'Amazing update!',
        content: 'The new features are absolutely fantastic! I love the improved user interface and the performance is incredible. Keep up the excellent work!',
        emotion: 'excited'
      },
      {
        from: 'complaints@store.com',
        subject: 'Terrible service experience',
        content: 'I am extremely angry about the poor service I received. The product was defective and customer support was unhelpful. This is completely unacceptable!',
        emotion: 'angry'
      }
    ];

    for (let i = 0; i < demoMessages.length; i++) {
      const msg = demoMessages[i];
      const analysis = this.analyzeEmotion(msg.content);
      
      const message: Message = {
        id: `gmail_demo_${Date.now()}_${i}`,
        platform: 'gmail',
        sender: msg.from,
        subject: msg.subject,
        content: msg.content,
        timestamp: new Date(Date.now() - (i * 3600000)), // Spread over hours
        emotion: analysis.emotion,
        confidence: analysis.confidence,
        priority: analysis.priority as any,
        rawData: { demo: true }
      };

      this.messages.unshift(message);
    }

    this.updateConnection('gmail', { 
      messageCount: this.messages.filter(m => m.platform === 'gmail').length,
      lastSync: new Date()
    });

    console.log(`✅ Generated ${demoMessages.length} demo Gmail messages`);
  }

  private async handleGmailAuthSuccess(code: string): Promise<void> {
    try {
      console.log('✅ Gmail OAuth code received, exchanging for tokens...');
      
      // Exchange code for tokens
      const tokenResponse = await this.exchangeGmailCodeForTokens(code);
      
      // Get user info
      const userInfo = await this.getGmailUserInfo(tokenResponse.access_token);
      
      // Store connection
      this.connections.set('gmail', {
        platform: 'gmail',
        connected: true,
        accessToken: tokenResponse.access_token,
        refreshToken: tokenResponse.refresh_token,
        lastSync: new Date(),
        messageCount: 0,
        userInfo
      });

      console.log('✅ Gmail connected successfully:', userInfo.email);
      
      // Start fetching messages
      await this.fetchGmailMessages();
      this.startSyncForPlatform('gmail');
      this.saveToStorage();
      
      // Trigger update event for dashboard components
      this.notifyConnectionUpdate();
      
    } catch (error) {
      console.error('❌ Gmail token exchange failed:', error);
      throw error;
    }
  }

  private async exchangeGmailCodeForTokens(code: string): Promise<any> {
    const response = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        client_id: this.OAUTH_CONFIG.gmail.clientId,
        client_secret: import.meta.env.VITE_GMAIL_CLIENT_SECRET || 'gmail-client-secret',
        code,
        grant_type: 'authorization_code',
        redirect_uri: this.OAUTH_CONFIG.gmail.redirectUri,
      }),
    });

    if (!response.ok) {
      throw new Error(`Token exchange failed: ${response.statusText}`);
    }

    return response.json();
  }

  private async getGmailUserInfo(accessToken: string): Promise<any> {
    const response = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to get user info: ${response.statusText}`);
    }

    return response.json();
  }

  private async fetchGmailMessages(): Promise<void> {
    try {
      const connection = this.connections.get('gmail');
      if (!connection?.accessToken) return;

      console.log('📧 Fetching real Gmail messages...');

      // Get message list
      const listResponse = await fetch(
        'https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=10&q=in:inbox',
        {
          headers: {
            'Authorization': `Bearer ${connection.accessToken}`,
          },
        }
      );

      if (!listResponse.ok) {
        throw new Error(`Gmail API error: ${listResponse.statusText}`);
      }

      const listData = await listResponse.json();
      
      if (!listData.messages) {
        console.log('📭 No Gmail messages found');
        return;
      }

      // Fetch individual messages
      for (const messageRef of listData.messages.slice(0, 5)) {
        try {
          const messageResponse = await fetch(
            `https://gmail.googleapis.com/gmail/v1/users/me/messages/${messageRef.id}`,
            {
              headers: {
                'Authorization': `Bearer ${connection.accessToken}`,
              },
            }
          );

          if (messageResponse.ok) {
            const messageData = await messageResponse.json();
            const processedMessage = this.processGmailMessage(messageData);
            
            if (processedMessage && !this.messages.find(m => m.id === processedMessage.id)) {
              this.messages.unshift(processedMessage);
            }
          }
        } catch (error) {
          console.error('❌ Error fetching individual message:', error);
        }
      }

      this.updateConnection('gmail', { 
        messageCount: this.messages.filter(m => m.platform === 'gmail').length,
        lastSync: new Date()
      });

      console.log(`✅ Processed ${this.messages.filter(m => m.platform === 'gmail').length} Gmail messages`);
      this.saveToStorage();
      
    } catch (error) {
      console.error('❌ Failed to fetch Gmail messages:', error);
    }
  }

  private processGmailMessage(messageData: any): Message | null {
    try {
      const headers = messageData.payload.headers;
      const subject = headers.find((h: any) => h.name === 'Subject')?.value || 'No Subject';
      const from = headers.find((h: any) => h.name === 'From')?.value || 'Unknown Sender';
      
      // Extract message body
      let content = '';
      if (messageData.payload.body?.data) {
        content = atob(messageData.payload.body.data.replace(/-/g, '+').replace(/_/g, '/'));
      } else if (messageData.payload.parts) {
        const textPart = messageData.payload.parts.find((part: any) => part.mimeType === 'text/plain');
        if (textPart?.body?.data) {
          content = atob(textPart.body.data.replace(/-/g, '+').replace(/_/g, '/'));
        }
      }

      if (!content) return null;

      // Analyze emotion
      const analysis = this.analyzeEmotion(content);

      return {
        id: `gmail_${messageData.id}`,
        platform: 'gmail',
        sender: from,
        subject,
        content: content.substring(0, 500), // Limit content length
        timestamp: new Date(parseInt(messageData.internalDate)),
        emotion: analysis.emotion,
        confidence: analysis.confidence,
        priority: analysis.priority as any,
        rawData: messageData
      };
    } catch (error) {
      console.error('❌ Error processing Gmail message:', error);
      return null;
    }
  }

  // SLACK REAL INTEGRATION
  async connectSlack(): Promise<void> {
    try {
      console.log('🔗 Starting real Slack OAuth2 integration...');
      
      // Check if real OAuth credentials are configured
      if (import.meta.env.VITE_SLACK_CLIENT_ID && import.meta.env.VITE_SLACK_CLIENT_ID !== 'demo-slack-client-id') {
        // Use real OAuth flow
        await this.performRealSlackOAuth();
      } else {
        // Use demo flow with user confirmation
        await this.performDemoSlackConnection();
      }
    } catch (error) {
      console.error('❌ Slack OAuth failed:', error);
      throw error;
    }
  }

  private async performRealSlackOAuth(): Promise<void> {
    // Build OAuth2 URL
    const authUrl = new URL('https://slack.com/oauth/v2/authorize');
    authUrl.searchParams.set('client_id', this.OAUTH_CONFIG.slack.clientId);
    authUrl.searchParams.set('scope', this.OAUTH_CONFIG.slack.scopes.join(','));
    authUrl.searchParams.set('redirect_uri', this.OAUTH_CONFIG.slack.redirectUri);
    authUrl.searchParams.set('state', 'slack_auth');

    // Open OAuth popup
    const popup = window.open(
      authUrl.toString(),
      'slack_oauth',
      'width=500,height=600,scrollbars=yes,resizable=yes'
    );

    if (!popup) {
      throw new Error('Popup blocked. Please allow popups for this site.');
    }

    // Wait for OAuth completion
    return new Promise((resolve, reject) => {
      const checkClosed = setInterval(() => {
        if (popup.closed) {
          clearInterval(checkClosed);
          reject(new Error('OAuth window was closed by user'));
        }
      }, 1000);

      const messageHandler = (event: MessageEvent) => {
        if (event.data.type === 'SLACK_AUTH_SUCCESS') {
          clearInterval(checkClosed);
          popup.close();
          window.removeEventListener('message', messageHandler);
          resolve();
        } else if (event.data.type === 'AUTH_ERROR') {
          clearInterval(checkClosed);
          popup.close();
          window.removeEventListener('message', messageHandler);
          reject(new Error(event.data.error));
        }
      };

      window.addEventListener('message', messageHandler);
    });
  }

  private async performDemoSlackConnection(): Promise<void> {
    // Show demo connection dialog
    const workspaceName = prompt(
      '💬 Slack Demo Integration\n\n' +
      'Since real OAuth credentials are not configured, we\'ll simulate the connection.\n\n' +
      'In production, this would:\n' +
      '• Open Slack OAuth popup\n' +
      '• Request workspace permissions\n' +
      '• Fetch your actual channel messages\n' +
      '• Analyze real conversation emotions\n\n' +
      'Enter your workspace name to simulate connection:'
    );

    if (!workspaceName) {
      throw new Error('Workspace name is required for Slack connection');
    }

    // Simulate OAuth success
    await this.simulateSlackConnection(workspaceName);
  }

  private async simulateSlackConnection(workspaceName: string): Promise<void> {
    // Store simulated connection
    this.connections.set('slack', {
      platform: 'slack',
      connected: true,
      accessToken: 'demo-slack-token',
      lastSync: new Date(),
      messageCount: 0,
      userInfo: { name: workspaceName, id: 'demo-workspace' }
    });

    console.log('✅ Slack demo connection established for workspace:', workspaceName);
    
    // Generate demo messages
    await this.generateDemoSlackMessages(workspaceName);
    this.startSyncForPlatform('slack');
    this.saveToStorage();
    
    // Trigger update event for dashboard components
    this.notifyConnectionUpdate();
  }

  private async generateDemoSlackMessages(workspaceName: string): Promise<void> {
    const demoMessages = [
      {
        user: 'john.doe',
        channel: 'general',
        text: 'Great job on the project launch everyone! The team did amazing work and I\'m really excited about the results.',
        emotion: 'excited'
      },
      {
        user: 'sarah.smith',
        channel: 'support',
        text: 'I\'m having trouble with the new deployment process. It\'s really frustrating and I can\'t figure out what\'s going wrong.',
        emotion: 'frustrated'
      },
      {
        user: 'mike.johnson',
        channel: 'dev-team',
        text: 'Can someone help me understand how the new API endpoints work? I\'m confused about the authentication flow.',
        emotion: 'confused'
      },
      {
        user: 'lisa.brown',
        channel: 'general',
        text: 'Thank you all for the warm welcome! I\'m happy to be part of this incredible team and looking forward to contributing.',
        emotion: 'happy'
      },
      {
        user: 'david.wilson',
        channel: 'urgent',
        text: 'The production server is down again! This is completely unacceptable and we\'re losing customers. We need to fix this immediately!',
        emotion: 'angry'
      }
    ];

    for (let i = 0; i < demoMessages.length; i++) {
      const msg = demoMessages[i];
      const analysis = this.analyzeEmotion(msg.text);
      
      const message: Message = {
        id: `slack_demo_${Date.now()}_${i}`,
        platform: 'slack',
        sender: `@${msg.user}`,
        subject: `Message in #${msg.channel}`,
        content: msg.text,
        timestamp: new Date(Date.now() - (i * 1800000)), // Spread over 30min intervals
        emotion: analysis.emotion,
        confidence: analysis.confidence,
        priority: analysis.priority as any,
        rawData: { demo: true, channel: msg.channel }
      };

      this.messages.unshift(message);
    }

    this.updateConnection('slack', { 
      messageCount: this.messages.filter(m => m.platform === 'slack').length,
      lastSync: new Date()
    });

    console.log(`✅ Generated ${demoMessages.length} demo Slack messages`);
  }

  private async handleSlackAuthSuccess(code: string): Promise<void> {
    try {
      console.log('✅ Slack OAuth code received, exchanging for tokens...');
      
      // Exchange code for tokens
      const tokenResponse = await this.exchangeSlackCodeForTokens(code);
      
      // Store connection
      this.connections.set('slack', {
        platform: 'slack',
        connected: true,
        accessToken: tokenResponse.access_token,
        lastSync: new Date(),
        messageCount: 0,
        userInfo: tokenResponse.team
      });

      console.log('✅ Slack connected successfully:', tokenResponse.team.name);
      
      // Start fetching messages
      await this.fetchSlackMessages();
      this.startSyncForPlatform('slack');
      this.saveToStorage();
      
      // Trigger update event for dashboard components
      this.notifyConnectionUpdate();
      
    } catch (error) {
      console.error('❌ Slack token exchange failed:', error);
      throw error;
    }
  }

  private async exchangeSlackCodeForTokens(code: string): Promise<any> {
    const response = await fetch('https://slack.com/api/oauth.v2.access', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        client_id: this.OAUTH_CONFIG.slack.clientId,
        client_secret: import.meta.env.VITE_SLACK_CLIENT_SECRET || 'slack-client-secret',
        code,
        redirect_uri: this.OAUTH_CONFIG.slack.redirectUri,
      }),
    });

    if (!response.ok) {
      throw new Error(`Slack token exchange failed: ${response.statusText}`);
    }

    const data = await response.json();
    if (!data.ok) {
      throw new Error(`Slack API error: ${data.error}`);
    }

    return data;
  }

  private async fetchSlackMessages(): Promise<void> {
    try {
      const connection = this.connections.get('slack');
      if (!connection?.accessToken) return;

      console.log('💬 Fetching real Slack messages...');

      // Get channels list
      const channelsResponse = await fetch('https://slack.com/api/conversations.list?types=public_channel,private_channel', {
        headers: {
          'Authorization': `Bearer ${connection.accessToken}`,
        },
      });

      if (!channelsResponse.ok) {
        throw new Error(`Slack API error: ${channelsResponse.statusText}`);
      }

      const channelsData = await channelsResponse.json();
      if (!channelsData.ok) {
        throw new Error(`Slack API error: ${channelsData.error}`);
      }

      // Fetch messages from first few channels
      for (const channel of channelsData.channels.slice(0, 3)) {
        try {
          const historyResponse = await fetch(
            `https://slack.com/api/conversations.history?channel=${channel.id}&limit=5`,
            {
              headers: {
                'Authorization': `Bearer ${connection.accessToken}`,
              },
            }
          );

          if (historyResponse.ok) {
            const historyData = await historyResponse.json();
            if (historyData.ok && historyData.messages) {
              for (const message of historyData.messages) {
                const processedMessage = this.processSlackMessage(message, channel);
                if (processedMessage && !this.messages.find(m => m.id === processedMessage.id)) {
                  this.messages.unshift(processedMessage);
                }
              }
            }
          }
        } catch (error) {
          console.error('❌ Error fetching Slack channel messages:', error);
        }
      }

      this.updateConnection('slack', { 
        messageCount: this.messages.filter(m => m.platform === 'slack').length,
        lastSync: new Date()
      });

      console.log(`✅ Processed ${this.messages.filter(m => m.platform === 'slack').length} Slack messages`);
      this.saveToStorage();
      
    } catch (error) {
      console.error('❌ Failed to fetch Slack messages:', error);
    }
  }

  private processSlackMessage(messageData: any, channel: any): Message | null {
    try {
      if (!messageData.text || messageData.subtype) return null;

      // Analyze emotion
      const analysis = this.analyzeEmotion(messageData.text);

      return {
        id: `slack_${messageData.ts}`,
        platform: 'slack',
        sender: messageData.user || 'Unknown User',
        subject: `Message in #${channel.name}`,
        content: messageData.text,
        timestamp: new Date(parseFloat(messageData.ts) * 1000),
        emotion: analysis.emotion,
        confidence: analysis.confidence,
        priority: analysis.priority as any,
        rawData: messageData
      };
    } catch (error) {
      console.error('❌ Error processing Slack message:', error);
      return null;
    }
  }

  // TELEGRAM REAL INTEGRATION
  async connectTelegram(): Promise<void> {
    try {
      console.log('🔗 Starting real Telegram Bot integration...');
      
      // Prompt for bot token
      const botToken = prompt(
        '🤖 Telegram Bot Integration\n\n' +
        'To connect Telegram, you need a Bot Token from @BotFather:\n\n' +
        '1. Open Telegram and search for @BotFather\n' +
        '2. Send /newbot and follow instructions\n' +
        '3. Copy the Bot Token and paste it below\n\n' +
        'Enter your Bot Token:'
      );

      if (!botToken) {
        throw new Error('Bot token is required for Telegram integration');
      }

      // Validate bot token format
      if (!botToken.match(/^\d+:[A-Za-z0-9_-]+$/)) {
        throw new Error('Invalid bot token format. Please get a valid token from @BotFather');
      }

      // Test bot token
      const botInfo = await this.validateTelegramBot(botToken);
      
      // Set up webhook
      await this.setupTelegramWebhook(botToken);

      // Store connection
      this.connections.set('telegram', {
        platform: 'telegram',
        connected: true,
        botToken,
        webhookUrl: this.OAUTH_CONFIG.telegram.webhookUrl,
        lastSync: new Date(),
        messageCount: 0,
        userInfo: botInfo
      });

      console.log('✅ Telegram bot connected successfully:', botInfo.username);
      
      // Start fetching messages
      await this.fetchTelegramMessages();
      this.startSyncForPlatform('telegram');
      this.saveToStorage();
      
      // Trigger update event for dashboard components
      this.notifyConnectionUpdate();
      
    } catch (error) {
      console.error('❌ Telegram integration failed:', error);
      throw error;
    }
  }

  private async validateTelegramBot(botToken: string): Promise<any> {
    const response = await fetch(`https://api.telegram.org/bot${botToken}/getMe`);
    
    if (!response.ok) {
      throw new Error('Invalid bot token or network error');
    }

    const data = await response.json();
    if (!data.ok) {
      throw new Error(`Telegram API error: ${data.description}`);
    }

    return data.result;
  }

  private async setupTelegramWebhook(botToken: string): Promise<void> {
    const response = await fetch(`https://api.telegram.org/bot${botToken}/setWebhook`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        url: this.OAUTH_CONFIG.telegram.webhookUrl,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to set up webhook');
    }

    const data = await response.json();
    if (!data.ok) {
      throw new Error(`Webhook setup failed: ${data.description}`);
    }
  }

  private async fetchTelegramMessages(): Promise<void> {
    try {
      const connection = this.connections.get('telegram');
      if (!connection?.botToken) return;

      console.log('📱 Fetching real Telegram messages...');

      // Get updates
      const response = await fetch(`https://api.telegram.org/bot${connection.botToken}/getUpdates?limit=10`);
      
      if (!response.ok) {
        throw new Error(`Telegram API error: ${response.statusText}`);
      }

      const data = await response.json();
      if (!data.ok) {
        throw new Error(`Telegram API error: ${data.description}`);
      }

      if (data.result && data.result.length > 0) {
        for (const update of data.result) {
          if (update.message && update.message.text) {
            const processedMessage = this.processTelegramMessage(update.message);
            if (processedMessage && !this.messages.find(m => m.id === processedMessage.id)) {
              this.messages.unshift(processedMessage);
            }
          }
        }

        this.updateConnection('telegram', { 
          messageCount: this.messages.filter(m => m.platform === 'telegram').length,
          lastSync: new Date()
        });

        console.log(`✅ Processed ${this.messages.filter(m => m.platform === 'telegram').length} Telegram messages`);
        this.saveToStorage();
      }
      
    } catch (error) {
      console.error('❌ Failed to fetch Telegram messages:', error);
    }
  }

  private processTelegramMessage(messageData: any): Message | null {
    try {
      if (!messageData.text) return null;

      // Analyze emotion
      const analysis = this.analyzeEmotion(messageData.text);

      return {
        id: `telegram_${messageData.message_id}`,
        platform: 'telegram',
        sender: `@${messageData.from.username || messageData.from.first_name}`,
        subject: 'Telegram Message',
        content: messageData.text,
        timestamp: new Date(messageData.date * 1000),
        emotion: analysis.emotion,
        confidence: analysis.confidence,
        priority: analysis.priority as any,
        rawData: messageData
      };
    } catch (error) {
      console.error('❌ Error processing Telegram message:', error);
      return null;
    }
  }

  // Utility methods
  private connectionUpdateListeners: (() => void)[] = [];
  
  public onConnectionUpdate(callback: () => void): () => void {
    this.connectionUpdateListeners.push(callback);
    // Return unsubscribe function
    return () => {
      const index = this.connectionUpdateListeners.indexOf(callback);
      if (index > -1) {
        this.connectionUpdateListeners.splice(index, 1);
      }
    };
  }
  
  private notifyConnectionUpdate(): void {
    console.log('🔄 PlatformService: Notifying connection update to', this.connectionUpdateListeners.length, 'listeners');
    this.connectionUpdateListeners.forEach(callback => {
      try {
        callback();
      } catch (error) {
        console.error('❌ Error in connection update callback:', error);
      }
    });
  }
  
  private startSyncForPlatform(platform: string) {
    const existingInterval = this.syncIntervals.get(platform);
    if (existingInterval) {
      clearInterval(existingInterval);
    }

    const syncInterval = setInterval(() => {
      this.syncPlatformData(platform);
    }, 30000); // Sync every 30 seconds

    this.syncIntervals.set(platform, syncInterval);
  }

  private async syncPlatformData(platform: string) {
    const connection = this.connections.get(platform);
    if (!connection?.connected) return;

    try {
      switch (platform) {
        case 'gmail':
          await this.fetchGmailMessages();
          break;
        case 'slack':
          await this.fetchSlackMessages();
          break;
        case 'telegram':
          await this.fetchTelegramMessages();
          break;
      }

      connection.lastSync = new Date();
      this.saveToStorage();
    } catch (error) {
      console.error(`❌ Failed to sync ${platform}:`, error);
    }
  }

  private updateConnection(platform: string, updates: Partial<PlatformConnection>): void {
    const connection = this.connections.get(platform);
    if (connection) {
      this.connections.set(platform, { ...connection, ...updates });
      this.saveToStorage();
    }
  }

  private saveToStorage() {
    try {
      const connectionsData = Array.from(this.connections.entries());
      localStorage.setItem('pulsedesk_connections', JSON.stringify(connectionsData));
      localStorage.setItem('pulsedesk_messages', JSON.stringify(this.messages));
    } catch (error) {
      console.error('❌ Failed to save to storage:', error);
    }
  }

  private loadPersistedData() {
    try {
      const connectionsData = localStorage.getItem('pulsedesk_connections');
      const messagesData = localStorage.getItem('pulsedesk_messages');
      
      if (connectionsData) {
        const connections = JSON.parse(connectionsData);
        this.connections = new Map(connections);
        
        // Restart sync for connected platforms
        this.connections.forEach((connection, platform) => {
          if (connection.connected) {
            this.startSyncForPlatform(platform);
          }
        });
      }
      
      if (messagesData) {
        const messages = JSON.parse(messagesData);
        this.messages = messages.map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp)
        }));
      }
    } catch (error) {
      console.error('❌ Failed to load from storage:', error);
      this.connections.clear();
      this.messages = [];
    }
  }

  // Public API methods
  public getConnection(platform: string): PlatformConnection | undefined {
    return this.connections.get(platform);
  }

  public getMessages(): Message[] {
    return [...this.messages].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  public getMessagesByPlatform(platform: string): Message[] {
    return this.messages.filter(m => m.platform === platform);
  }

  public disconnect(platform: string): void {
    this.connections.delete(platform);
    const interval = this.syncIntervals.get(platform);
    if (interval) {
      clearInterval(interval);
      this.syncIntervals.delete(platform);
    }
    this.messages = this.messages.filter(m => m.platform !== platform);
    this.saveToStorage();
  }

  public getConnectedPlatforms(): string[] {
    return Array.from(this.connections.entries())
      .filter(([_, connection]) => connection.connected)
      .map(([platform, _]) => platform);
  }

  public getTotalMessageCount(): number {
    const connectedPlatforms = this.getConnectedPlatforms();
    if (connectedPlatforms.length === 0) return 0;
    return this.messages.length;
  }

  public getUrgentMessageCount(): number {
    const connectedPlatforms = this.getConnectedPlatforms();
    if (connectedPlatforms.length === 0) return 0;
    return this.messages.filter(m => 
      connectedPlatforms.includes(m.platform) && m.priority === 'urgent'
    ).length;
  }

  public getPositiveSentimentPercentage(): number {
    const connectedMessages = this.messages.filter(m => 
      this.getConnectedPlatforms().includes(m.platform)
    );
    if (this.getConnectedPlatforms().length === 0) return 0;
    const positiveEmotions = connectedMessages.filter(m => 
      m.emotion === 'happy' || m.emotion === 'excited'
    ).length;
    return connectedMessages.length > 0 ? Math.round((positiveEmotions / connectedMessages.length) * 100) : 0;
  }

  public getNegativeSentimentPercentage(): number {
    const connectedMessages = this.messages.filter(m => 
      this.getConnectedPlatforms().includes(m.platform)
    );
    if (this.getConnectedPlatforms().length === 0) return 0;
    const negativeEmotions = connectedMessages.filter(m => 
      m.emotion === 'angry' || m.emotion === 'frustrated' || m.emotion === 'sad'
    ).length;
    return connectedMessages.length > 0 ? Math.round((negativeEmotions / connectedMessages.length) * 100) : 0;
  }

  public getEmotionStats() {
    if (this.messages.length === 0) {
      return { happy: 0, neutral: 0, confused: 0, frustrated: 0, angry: 0, excited: 0, sad: 0 };
    }

    const emotions = this.messages.map(m => m.emotion).filter(Boolean);
    const total = emotions.length;
    
    if (total === 0) return { happy: 0, neutral: 0, confused: 0, frustrated: 0, angry: 0, excited: 0, sad: 0 };
    
    return {
      happy: Math.round((emotions.filter(e => e === 'happy').length / total) * 100),
      excited: Math.round((emotions.filter(e => e === 'excited').length / total) * 100),
      neutral: Math.round((emotions.filter(e => e === 'neutral').length / total) * 100),
      confused: Math.round((emotions.filter(e => e === 'confused').length / total) * 100),
      frustrated: Math.round((emotions.filter(e => e === 'frustrated').length / total) * 100),
      angry: Math.round((emotions.filter(e => e === 'angry').length / total) * 100),
      sad: Math.round((emotions.filter(e => e === 'sad').length / total) * 100)
    };
  }

  public getAllMessages(): Message[] {
    return this.getMessages();
  }

  public async deleteAccount(): Promise<void> {
    try {
      this.connections.clear();
      this.messages = [];
      
      this.syncIntervals.forEach(interval => clearInterval(interval));
      this.syncIntervals.clear();
      
      localStorage.removeItem('pulsedesk_connections');
      localStorage.removeItem('pulsedesk_messages');
      localStorage.removeItem('pulsedesk_profile');
      localStorage.removeItem('pulsedesk_notifications');
      localStorage.removeItem('pulsedesk_privacy');
      localStorage.removeItem('pulsedesk_preferences');
      
      await signOut(auth);
      
      console.log('✅ Account deleted successfully');
    } catch (error) {
      console.error('❌ Failed to delete account:', error);
      throw error;
    }
  }
}

export const platformService = new PlatformService();