import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { auth } from '../firebase';
import { User, onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth';
import { googleProvider } from '../firebase';
import toast from 'react-hot-toast';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  signInWithGoogle: async () => {},
  logout: async () => {}
});

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

// Email service for welcome emails
const sendWelcomeEmail = async (userEmail: string, userName: string) => {
  try {
    console.log('📧 Sending welcome email to:', userEmail);
    const emailData = {
      to: userEmail,
      from: 'pulsedesk.care@gmail.com',
      subject: 'Welcome to PulseDesk 🎉',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px 20px; border-radius: 10px;">
          <div style="background: white; padding: 30px; border-radius: 10px; text-align: center;">
            <h1 style="color: #333; margin-bottom: 20px;">Welcome to PulseDesk! 🎉</h1>
            <p style="color: #666; font-size: 18px; margin-bottom: 20px;">Hi ${userName},</p>
            <p style="color: #666; font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
              Welcome to PulseDesk – Your smart emotion-aware support assistant created by Shanmukh and Praveen!
            </p>
            <div style="margin: 30px 0;">
              <h3 style="color: #333; margin-bottom: 15px;">What's Next?</h3>
              <ul style="text-align: left; color: #666; line-height: 1.8;">
                <li>📊 View real-time emotion analytics in your dashboard</li>
                <li>🔔 Set up smart alerts for negative sentiment spikes</li>
                <li>📈 Track customer satisfaction trends over time</li>
                <li>🤖 Let our AI help you respond with empathy</li>
              </ul>
            </div>
            <a href="https://pulsedesk.netlify.app/dashboard" style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 25px; font-weight: bold; margin: 20px 0;">
              Go to Dashboard
            </a>
            <p style="color: #999; font-size: 14px; margin-top: 30px;">
              Created with ❤️ by Shanmukh & Praveen | Need help? Reply to this email.
            </p>
          </div>
        </div>
      `
    };

    // In production, this would send via your backend API
    console.log('✅ Welcome email prepared:', emailData);
    
    // Simulate successful email sending
    toast.success('Welcome email sent successfully!');
    return Promise.resolve({ success: true });
  } catch (error) {
    console.error('❌ Failed to send welcome email:', error);
    toast.error('Failed to send welcome email');
    return Promise.reject(error);
  }
};

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    console.log('🔐 Setting up auth state listener...');
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      console.log('🔄 Auth state changed:', {
        user: user ? {
          uid: user.uid,
          email: user.email,
          displayName: user.displayName
        } : null,
        timestamp: new Date().toISOString()
      });
      setUser(user);
      setLoading(false);
      
      if (user) {
        console.log('✅ User authenticated successfully');
        toast.success(`Welcome back, ${user.displayName || 'User'}!`);
      }
    });
    
    return unsubscribe;
  }, []);

  const signInWithGoogle = async () => {
    try {
      console.log('🚀 AuthContext: Starting Google sign-in...');
      setLoading(true);
      
      // Clear any existing auth state
      await signOut(auth);
      
      const result = await signInWithPopup(auth, googleProvider);
      console.log("✅ AuthContext: User signed in successfully:", {
        uid: result.user.uid,
        email: result.user.email,
        displayName: result.user.displayName
      });
      
      // Send welcome email for new users
      if (result.user) {
        try {
          const isNewUser = result.additionalUserInfo?.isNewUser;
          console.log('🆕 AuthContext: Is new user:', isNewUser);
          if (isNewUser) {
            console.log('📧 AuthContext: Sending welcome email for new user...');
            await sendWelcomeEmail(
              result.user.email || '',
              result.user.displayName || 'User'
            );
            console.log('✅ AuthContext: Welcome email sent successfully');
            toast.success('Welcome to PulseDesk! Check your email for getting started guide.');
          } else {
            toast.success('Welcome back to PulseDesk!');
          }
        } catch (emailError) {
          console.error('❌ AuthContext: Failed to send welcome email:', emailError);
          // Don't fail the login if email fails
        }
      }
      setLoading(false);
      
      // Force navigation to dashboard
      console.log('🎯 AuthContext: Forcing navigation to dashboard...');
      setTimeout(() => {
        window.location.href = '/dashboard';
      }, 100);
      
    } catch (error) {
      console.error('❌ AuthContext: Error signing in with Google:', error);
      setLoading(false);
      toast.error('Failed to sign in with Google. Please try again.');
      throw error;
    }
  };

  const logout = async () => {
    try {
      console.log('🚪 AuthContext: Signing out user...');
      await signOut(auth);
      console.log('✅ AuthContext: User signed out successfully');
      toast.success('Signed out successfully');
    } catch (error) {
      console.error('❌ AuthContext: Error signing out:', error);
      toast.error('Failed to sign out');
    }
  };

  const value: AuthContextType = {
    user,
    loading,
    signInWithGoogle,
    logout
  };

  console.log('🔐 AuthContext: Provider rendering with:', {
    hasUser: !!user,
    loading,
    userEmail: user?.email
  });
  
  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};