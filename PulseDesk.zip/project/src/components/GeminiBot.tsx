import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ChatBubbleLeftRightIcon,
  XMarkIcon,
  PaperAirplaneIcon,
  SparklesIcon
} from '@heroicons/react/24/outline';
import { platformService } from '../services/platformService';

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

const GeminiBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hi! I'm PulseBot, your AI assistant created by Shanmukh and Praveen. I can help you with questions about PulseDesk and customer support best practices. What would you like to know?",
      isBot: true,
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateResponse = async (userMessage: string): Promise<string> => {
    setIsTyping(true);
    
    // Get real data from platform service for contextual responses
    const connectedPlatforms = platformService.getConnectedPlatforms();
    const totalMessages = platformService.getTotalMessageCount();
    const urgentMessages = platformService.getUrgentMessageCount();
    const positiveSentiment = platformService.getPositiveSentimentPercentage();
    const negativeSentiment = platformService.getNegativeSentimentPercentage();
    const emotionStats = platformService.getEmotionStats();
    
    // Enhanced AI-powered response logic with real data
    const lowerMessage = userMessage.toLowerCase();
    
    // Creator information
    if (lowerMessage.includes('who made') || lowerMessage.includes('creator') || lowerMessage.includes('developer') || lowerMessage.includes('built') || lowerMessage.includes('shanmukh') || lowerMessage.includes('praveen')) {
      return "🚀 PulseDesk was created by two amazing developers: **Shanmukh** and **Praveen**! They built this emotion-aware customer support platform to revolutionize how businesses understand and respond to customer emotions. You can check out their individual work - Shanmukh's portfolio and Praveen's ML projects showcase their incredible skills in web development and machine learning!";
    }
    
    // Real-time data queries
    if (lowerMessage.includes('how many messages') || lowerMessage.includes('message count') || lowerMessage.includes('total messages')) {
      if (totalMessages === 0) {
        return "📊 You haven't connected any platforms yet, so I don't see any messages in your system. Connect Gmail, Slack, or Telegram to start analyzing real customer conversations! Once connected, I'll be able to give you detailed message statistics.";
      }
      return `📊 Great question! I can see you have ${totalMessages} messages across your connected platforms (${connectedPlatforms.join(', ')}). Out of these, ${urgentMessages} require urgent attention. Your current sentiment breakdown shows ${positiveSentiment}% positive and ${negativeSentiment}% negative emotions. Would you like me to dive deeper into any specific platform or emotion category?`;
    }
    
    // Sentiment analysis queries
    if (lowerMessage.includes('sentiment') || lowerMessage.includes('emotion') || lowerMessage.includes('feeling') || lowerMessage.includes('mood')) {
      if (totalMessages === 0) {
        return "🎭 I'd love to analyze emotions for you, but I need some data first! Connect your Gmail, Slack, or Telegram accounts so I can start analyzing the emotional tone of your customer conversations. Once connected, I'll provide real-time sentiment insights and help you identify when customers need extra attention.";
      }
      
      const topEmotion = Object.entries(emotionStats).reduce((a, b) => emotionStats[a[0]] > emotionStats[b[0]] ? a : b);
      return `🎭 Based on your real message data, here's what I'm seeing: ${positiveSentiment}% positive sentiment, ${negativeSentiment}% negative sentiment. The most common emotion is "${topEmotion[0]}" at ${topEmotion[1]}%. ${urgentMessages > 0 ? `⚠️ You have ${urgentMessages} urgent messages that need immediate attention!` : '✅ No urgent issues detected right now.'} Would you like specific recommendations for improving customer satisfaction?`;
    }
    
    // Platform-specific queries
    if (lowerMessage.includes('gmail') || lowerMessage.includes('email')) {
      const gmailConnected = connectedPlatforms.includes('gmail');
      const gmailMessages = platformService.getMessagesByPlatform('gmail').length;
      
      if (!gmailConnected) {
        return "📧 I notice Gmail isn't connected yet! Once you connect your Gmail account, I'll analyze all your customer emails for emotional tone, urgency levels, and sentiment trends. This helps you prioritize responses and catch frustrated customers before they escalate. Ready to connect Gmail?";
      }
      
      return `📧 Your Gmail integration is active! I've analyzed ${gmailMessages} emails so far. ${gmailMessages > 0 ? `The emotion analysis shows patterns in customer communication that can help you respond more effectively. Want me to highlight any concerning trends or positive feedback?` : 'I\'m monitoring for new emails and will analyze them as they arrive.'}`;
    }
    
    // Comprehensive PulseDesk information
    if (lowerMessage.includes('what is pulsedesk') || lowerMessage.includes('about pulsedesk') || lowerMessage.includes('pulsedesk')) {
      return `🚀 PulseDesk is your emotion-aware customer support AI created by Shanmukh and Praveen! ${totalMessages > 0 ? `Right now, I'm actively analyzing ${totalMessages} real messages from your connected platforms (${connectedPlatforms.join(', ')}) and providing live sentiment insights.` : 'I\'m ready to analyze your customer conversations once you connect Gmail, Slack, or Telegram.'} I help you understand customer emotions, catch issues before they escalate, and respond with perfect empathy. Think of me as your emotional intelligence superpower!`;
    }
    
    // Greetings
    if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey') || lowerMessage.includes('good')) {
      const greeting = totalMessages > 0 
        ? `I can see you're actively using PulseDesk with ${totalMessages} messages analyzed across ${connectedPlatforms.length} platforms!`
        : 'Ready to help you get started with emotion-aware customer support!';
      return `👋 Hello! I'm PulseBot, your AI assistant for PulseDesk, created by Shanmukh and Praveen. ${greeting} I can help you understand your customer emotions, explain platform features, or dive into your real-time analytics. What would you like to explore?`;
    }
    
    // Help and support
    if (lowerMessage.includes('help') || lowerMessage.includes('support') || lowerMessage.includes('assist')) {
      return "🤝 I'm absolutely here to help! Think of me as your personal guide to PulseDesk's amazing features built by Shanmukh and Praveen. Ask me about emotion detection, platform integrations, pricing, analytics, or even general customer support best practices. I love sharing knowledge and helping teams succeed!";
    }
    
    // Default creative response
    const creativeResponses = [
      `🌟 That's a fascinating question! ${totalMessages > 0 ? `Based on your ${totalMessages} messages, I can see you're actively using PulseDesk.` : 'I specialize in PulseDesk and customer support excellence.'} This platform was crafted by Shanmukh and Praveen to revolutionize customer support. What aspect interests you most?`,
      
      `💡 Interesting! ${connectedPlatforms.length > 0 ? `I can see you have ${connectedPlatforms.join(', ')} connected, which gives me great context.` : 'I\'m passionate about helping teams understand customer emotions better.'} Shanmukh and Praveen built PulseDesk to transform support experiences. What would you like to explore?`,
      
      `🚀 Great question! ${totalMessages > 0 ? `With ${totalMessages} messages in your system, there's lots to explore.` : 'As your PulseDesk guide, I\'m here to help you navigate emotion-aware customer support.'} This innovative platform by Shanmukh and Praveen offers incredible insights. What can I help you discover?`
    ];
    
    const randomIndex = Math.floor(Math.random() * creativeResponses.length);
    return creativeResponses[randomIndex];
  };

  const handleSend = async () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');

    try {
      const response = await generateResponse(inputText);
      
      setTimeout(() => {
        const botMessage: Message = {
          id: (Date.now() + 1).toString(),
          text: response,
          isBot: true,
          timestamp: new Date()
        };
        setMessages(prev => [...prev, botMessage]);
        setIsTyping(false);
      }, 1000);
    } catch (error) {
      setIsTyping(false);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: "I'm sorry, I'm having trouble responding right now. Please try again later or contact our support team for help.",
        isBot: true,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* Chat Button */}
      <motion.button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full shadow-lg flex items-center justify-center z-50 hover:shadow-xl transition-all duration-300 ${
          isOpen ? 'scale-0' : 'scale-100'
        }`}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
      >
        <ChatBubbleLeftRightIcon className="w-6 h-6 text-white" />
      </motion.button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="fixed bottom-6 right-6 w-96 h-[32rem] bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl shadow-2xl z-50 flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-500/20 to-purple-600/20 border-b border-white/10 p-4 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-purple-600 rounded-lg flex items-center justify-center">
                  <SparklesIcon className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="text-white font-semibold">PulseBot</h3>
                  <p className="text-xs text-gray-300">AI Assistant</p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="text-gray-400 hover:text-white transition-colors p-1"
              >
                <XMarkIcon className="w-5 h-5" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
                >
                  <div
                    className={`max-w-xs px-4 py-3 rounded-2xl text-sm ${
                      message.isBot
                        ? 'bg-white/10 text-gray-200 border border-white/10'
                        : 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                    }`}
                  >
                    {message.text}
                  </div>
                </motion.div>
              ))}

              {/* Typing Indicator */}
              {isTyping && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex justify-start"
                >
                  <div className="bg-white/10 border border-white/10 px-4 py-3 rounded-2xl text-sm text-gray-200">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </motion.div>
              )}
              
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="border-t border-white/10 p-4">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask me about PulseDesk..."
                  className="flex-1 bg-white/10 border border-white/20 text-white placeholder-gray-400 px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                />
                <button
                  onClick={handleSend}
                  disabled={!inputText.trim() || isTyping}
                  className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-3 rounded-xl hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <PaperAirplaneIcon className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default GeminiBot;