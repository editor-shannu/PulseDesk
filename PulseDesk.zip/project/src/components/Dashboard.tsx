import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { 
  HomeIcon,
  CpuChipIcon,
  ChartBarIcon,
  UserIcon,
  Cog6ToothIcon,
  ArrowRightStartOnRectangleIcon,
  BellIcon
} from '@heroicons/react/24/outline';
import DashboardHome from './dashboard/DashboardHome';
import PlatformIntegration from './dashboard/PlatformIntegration';
import LiveTicketMonitor from './dashboard/LiveTicketMonitor';
import AnalyticsDashboard from './dashboard/AnalyticsDashboard';
import UserProfile from './dashboard/UserProfile';
import toast from 'react-hot-toast';

const Dashboard: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('home');

  console.log('📊 Dashboard: Rendering for user:', user?.email, 'activeTab:', activeTab);

  // Add safety check for user
  if (!user) {
    console.error('❌ Dashboard: No user found, redirecting to login');
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-red-400 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <div className="w-8 h-8 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
          </div>
          <p className="text-white text-xl font-semibold">Authentication Required</p>
          <button 
            onClick={() => navigate('/login')}
            className="mt-4 bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600"
          >
            Go to Login
          </button>
        </div>
      </div>
    );
  }

  // Safe navigation array with error handling
  const navigation = [
    { 
      id: 'home', 
      name: 'Dashboard', 
      icon: HomeIcon, 
      component: DashboardHome 
    },
    { 
      id: 'platforms', 
      name: 'Platform Integration', 
      icon: CpuChipIcon, 
      component: PlatformIntegration 
    },
    { 
      id: 'tickets', 
      name: 'Live Tickets', 
      icon: BellIcon, 
      component: LiveTicketMonitor 
    },
    { 
      id: 'analytics', 
      name: 'Analytics', 
      icon: ChartBarIcon, 
      component: AnalyticsDashboard 
    },
    { 
      id: 'profile', 
      name: 'Profile', 
      icon: UserIcon, 
      component: UserProfile 
    },
  ];

  // Safe component resolution with fallback
  const activeNavItem = navigation.find(nav => nav.id === activeTab);
  const ActiveComponent = activeNavItem?.component || DashboardHome;

  const handleLogout = async () => {
    try {
      console.log('🚪 Dashboard: Logging out user...');
      await logout();
      toast.success('Successfully logged out');
      navigate('/');
    } catch (error) {
      console.error('❌ Dashboard: Logout error:', error);
      toast.error('Failed to logout');
    }
  };

  const handleTabChange = (tabId: string) => {
    console.log(`🔄 Dashboard: Switching to tab: ${tabId}`);
    setActiveTab(tabId);
  };

  console.log('✅ Dashboard: Rendering UI for user:', user?.email);

  // Add try-catch for rendering
  try {
  return (
    <div 
      className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900"
      style={{ 
        minHeight: '100vh',
        width: '100%',
        position: 'relative',
        zIndex: 1
      }}
    >
      <div className="flex h-screen">
        {/* Sidebar */}
        <motion.aside 
          initial={{ x: -300 }}
          animate={{ x: 0 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="w-64 bg-black/20 backdrop-blur-sm border-r border-white/10 flex-shrink-0"
          style={{ height: '100vh', overflow: 'hidden' }}
        >
          <div className="p-6 h-full flex flex-col">
            {/* Logo */}
            <div className="flex items-center space-x-3 mb-8">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-purple-600 rounded-xl flex items-center justify-center">
                <Cog6ToothIcon className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                PulseDesk
              </h1>
            </div>

            {/* User Info */}
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-4 rounded-xl mb-8">
              <div className="flex items-center space-x-3">
                <img 
                  src={user?.photoURL || 'https://via.placeholder.com/40'} 
                  alt="Avatar" 
                  className="w-10 h-10 rounded-full"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://via.placeholder.com/40';
                  }}
                />
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium truncate">
                    {user?.displayName || 'User'}
                  </p>
                  <p className="text-gray-400 text-sm truncate">
                    {user?.email}
                  </p>
                </div>
              </div>
            </div>

            {/* Navigation */}
            <nav className="space-y-2 flex-1">
              {navigation.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleTabChange(item.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                    activeTab === item.id
                      ? 'bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-blue-400/30 text-white'
                      : 'text-gray-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium">{item.name}</span>
                </button>
              ))}
            </nav>

            {/* Logout Button */}
            <div className="mt-8 pt-8 border-t border-white/10">
              <button
                onClick={handleLogout}
                className="w-full flex items-center space-x-3 px-4 py-3 text-gray-300 hover:text-white hover:bg-red-500/10 rounded-xl transition-all duration-300"
              >
                  <ArrowRightStartOnRectangleIcon className="w-5 h-5" />
                <span className="font-medium">Sign Out</span>
              </button>
            </div>
          </div>
        </motion.aside>

        {/* Main Content */}
        <main 
          className="flex-1 overflow-auto"
          style={{ 
            height: '100vh',
            backgroundColor: 'transparent',
            minWidth: 0
          }}
        >
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="p-8"
            style={{ 
              minHeight: '100%',
              backgroundColor: 'transparent'
            }}
          >
            <React.Suspense fallback={
              <div className="flex items-center justify-center py-20">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 animate-pulse">
                    <div className="w-8 h-8 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  </div>
                    <p className="text-white text-xl font-semibold">Loading {activeNavItem?.name || 'Dashboard'}...</p>
                </div>
              </div>
            }>
                {ActiveComponent && <ActiveComponent />}
            </React.Suspense>
          </motion.div>
        </main>
      </div>
    </div>
  );
  } catch (error) {
    console.error('❌ Dashboard: Render error:', error);
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-center text-white">
          <h1 className="text-2xl font-bold mb-4">Dashboard Error</h1>
          <p className="mb-4">There was an issue loading the dashboard.</p>
          <button 
            onClick={() => window.location.reload()}
            className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600"
          >
            Refresh Page
          </button>
        </div>
      </div>
    );
  }
};

export default Dashboard;