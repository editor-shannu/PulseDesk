import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Mail, MessageSquare, Send, Shield, CheckCircle, AlertCircle, ExternalLink, Key, Zap } from 'lucide-react';
import { platformService } from '../../services/platformService';
import toast from 'react-hot-toast';

interface Platform {
  id: string;
  name: string;
  icon: React.ReactNode;
  color: string;
  description: string;
  connected: boolean;
  oauthUrl?: string;
  scopes?: string[];
}

const PlatformIntegration: React.FC = () => {
  const [platforms, setPlatforms] = useState<Platform[]>([
    {
      id: 'gmail',
      name: 'Gmail',
      icon: <Mail className="w-6 h-6" />,
      color: 'bg-red-500',
      description: 'OAuth2 integration with Gmail API for email sentiment analysis',
      connected: false,
      scopes: ['gmail.readonly', 'userinfo.email', 'userinfo.profile', 'openid']
    },
    {
      id: 'slack',
      name: 'Slack',
      icon: <MessageSquare className="w-6 h-6" />,
      color: 'bg-purple-500',
      description: 'OAuth2 integration with Slack API for workspace message analysis',
      connected: false,
      scopes: ['channels:read', 'chat:write', 'users:read']
    },
    {
      id: 'telegram',
      name: 'Telegram',
      icon: <Send className="w-6 h-6" />,
      color: 'bg-blue-500',
      description: 'Bot API integration with webhook for real-time message processing',
      connected: false,
      scopes: ['bot:messages', 'webhook:receive']
    }
  ]);

  const [isConnecting, setIsConnecting] = useState<string | null>(null);

  // Load connection status from platformService
  useEffect(() => {
    const updateConnectionStatus = () => {
      console.log('🔄 PlatformIntegration: Updating connection status...');
      setPlatforms(prev => prev.map(platform => ({
        ...platform,
        connected: platformService.getConnection(platform.id)?.connected || false
      })));
    };

    updateConnectionStatus();
    // Update every 3 seconds to reflect real connection status
    const interval = setInterval(updateConnectionStatus, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleConnect = async (platformId: string) => {
    setIsConnecting(platformId);
    
    try {
      console.log(`🔗 Starting real ${platformId} integration...`);
      
      if (platformId === 'gmail') {
        await platformService.connectGmail();
        toast.success('✅ Gmail connected successfully! Real OAuth2 integration active.');
      } else if (platformId === 'slack') {
        await platformService.connectSlack();
        toast.success('✅ Slack connected successfully! Real OAuth2 integration active.');
      } else if (platformId === 'telegram') {
        await platformService.connectTelegram();
        toast.success('✅ Telegram connected successfully! Real Bot API integration active.');
      }
      
      // Update connection status
      setPlatforms(prev => prev.map(platform => 
        platform.id === platformId 
          ? { ...platform, connected: true }
          : platform
      ));
    } catch (error) {
      console.error(`❌ ${platformId} connection failed:`, error);
      if (error instanceof Error) {
        if (error.message.includes('cancelled') || error.message.includes('closed')) {
          toast.error(`${platformId} connection cancelled by user.`);
        } else if (error.message.includes('popup')) {
          toast.error(`Please allow popups for ${platformId} OAuth integration.`);
        } else {
          toast.error(`❌ ${platformId} integration failed: ${error.message}`);
        }
      } else {
        toast.error(`❌ Failed to connect ${platformId}. Please check your credentials.`);
      }
    } finally {
      setIsConnecting(null);
    }
  };

  const handleDisconnect = (platformId: string) => {
    try {
      const confirmed = window.confirm(
        `🔌 Disconnect Real ${platformId.charAt(0).toUpperCase() + platformId.slice(1)} Integration?\n\n` +
        `This will:\n` +
        `• Revoke OAuth2 access tokens\n` +
        `• Stop real-time message fetching\n` +
        `• Remove all stored messages and analysis\n` +
        `• Deactivate AI emotion monitoring\n\n` +
        `You can reconnect with OAuth2 anytime.`
      );
      
      if (!confirmed) return;
      
      platformService.disconnect(platformId);
      toast.success(`🔌 ${platformId.charAt(0).toUpperCase() + platformId.slice(1)} real integration disconnected!`);
      
      // Update UI
      setPlatforms(prev => prev.map(platform => 
        platform.id === platformId 
          ? { ...platform, connected: false }
          : platform
      ));
    } catch (error) {
      console.error(`❌ Failed to disconnect ${platformId}:`, error);
      toast.error(`❌ Failed to disconnect ${platformId}`);
    }
  };

  const connectedCount = platforms.filter(p => p.connected).length;
  const connectedPlatforms = platformService.getConnectedPlatforms();

  return (
    <div className="space-y-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2 flex items-center">
            <Zap className="w-8 h-8 mr-3 text-yellow-400" />
            Real Platform Integration Hub
          </h1>
          <p className="text-gray-400">
            Real OAuth2 & API integrations for Gmail, Slack, and Telegram with live emotion analysis
          </p>
        </div>

        {/* Real Integration Status */}
        <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-blue-400/30 p-6 rounded-2xl mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <Key className="w-6 h-6 text-blue-400" />
            <h2 className="text-xl font-bold text-white">Platform Integration Status</h2>
          </div>
          
          <div className="mb-4 p-3 bg-yellow-500/20 border border-yellow-400/30 rounded-lg">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
              <span className="text-yellow-400 font-medium">Demo Mode Active</span>
            </div>
            <p className="text-yellow-300 text-sm mt-1">
              Real OAuth credentials not configured. Using demo integration flow. Add VITE_GMAIL_CLIENT_ID and VITE_SLACK_CLIENT_ID to .env for real OAuth.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white/10 p-4 rounded-xl">
              <h3 className="font-semibold text-white mb-2">Gmail Integration</h3>
              <p className="text-sm text-gray-300">
                {import.meta.env.VITE_GMAIL_CLIENT_ID && import.meta.env.VITE_GMAIL_CLIENT_ID !== 'demo-gmail-client-id' 
                  ? 'Real Google OAuth2 with API access' 
                  : 'Demo mode - simulated Gmail connection'}
              </p>
              <div className="flex items-center mt-2">
                <div className={`w-2 h-2 rounded-full mr-2 ${platforms.find(p => p.id === 'gmail')?.connected ? 'bg-green-400' : 'bg-gray-400'}`} />
                <span className="text-xs text-gray-400">
                  {platforms.find(p => p.id === 'gmail')?.connected ? 'Connected & Active' : 'Not Connected'}
                </span>
              </div>
            </div>
            <div className="bg-white/10 p-4 rounded-xl">
              <h3 className="font-semibold text-white mb-2">Slack Integration</h3>
              <p className="text-sm text-gray-300">
                {import.meta.env.VITE_SLACK_CLIENT_ID && import.meta.env.VITE_SLACK_CLIENT_ID !== 'demo-slack-client-id' 
                  ? 'Real Slack OAuth2 with workspace access' 
                  : 'Demo mode - simulated Slack connection'}
              </p>
              <div className="flex items-center mt-2">
                <div className={`w-2 h-2 rounded-full mr-2 ${platforms.find(p => p.id === 'slack')?.connected ? 'bg-green-400' : 'bg-gray-400'}`} />
                <span className="text-xs text-gray-400">
                  {platforms.find(p => p.id === 'slack')?.connected ? 'Connected & Active' : 'Not Connected'}
                </span>
              </div>
            </div>
            <div className="bg-white/10 p-4 rounded-xl">
              <h3 className="font-semibold text-white mb-2">Telegram Integration</h3>
              <p className="text-sm text-gray-300">Real Bot API with webhook integration</p>
              <div className="flex items-center mt-2">
                <div className={`w-2 h-2 rounded-full mr-2 ${platforms.find(p => p.id === 'telegram')?.connected ? 'bg-green-400' : 'bg-gray-400'}`} />
                <span className="text-xs text-gray-400">
                  {platforms.find(p => p.id === 'telegram')?.connected ? 'Connected & Active' : 'Not Connected'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Platform Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {platforms.map((platform) => (
            <motion.div
              key={platform.id}
              className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20"
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex items-center mb-4">
                <div className={`${platform.color} p-3 rounded-lg mr-4`}>
                  {platform.icon}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold">{platform.name}</h3>
                  <div className="flex items-center mt-1">
                    {platform.connected ? (
                      <>
                        <CheckCircle className="w-4 h-4 text-green-400 mr-1" />
                        <span className="text-green-400 text-sm">Connected</span>
                        <span className="ml-2 text-xs bg-green-500/20 text-green-300 px-2 py-1 rounded-full">
                          Real API Active
                        </span>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-4 h-4 text-gray-400 mr-1" />
                        <span className="text-gray-400 text-sm">Not Connected</span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <p className="text-gray-300 text-sm mb-4">
                {platform.description}
              </p>

              {/* OAuth Scopes */}
              {platform.scopes && (
                <div className="mb-4">
                  <div className="flex items-center mb-2">
                    <Shield className="w-4 h-4 text-blue-400 mr-1" />
                    <span className="text-xs text-blue-400 font-medium">Real API Scopes</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {platform.scopes.map((scope, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-blue-500/20 text-blue-300 text-xs rounded-full"
                      >
                        {scope}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Button */}
              <div className="flex gap-2">
                {platform.connected ? (
                  <button
                    onClick={() => handleDisconnect(platform.id)}
                    className="flex-1 bg-red-500/20 hover:bg-red-500/30 text-red-300 px-4 py-2 rounded-lg transition-colors duration-200"
                  >
                    Disconnect
                  </button>
                ) : (
                  <button
                    onClick={() => handleConnect(platform.id)}
                    disabled={isConnecting === platform.id}
                    className={`flex-1 ${platform.color} hover:opacity-90 text-white px-4 py-2 rounded-lg transition-all duration-200 flex items-center justify-center ${
                      isConnecting === platform.id ? 'opacity-50 cursor-not-allowed' : ''
                    }`}
                  >
                    {isConnecting === platform.id ? (
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    ) : (
                      <ExternalLink className="w-4 h-4 mr-2" />
                    )}
                    {isConnecting === platform.id ? 'Connecting...' : `Connect ${platform.name}`}
                  </button>
                )}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Integration Guide */}
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20 mb-8">
          <h2 className="text-2xl font-bold mb-6 flex items-center">
            <Key className="w-6 h-6 mr-2 text-yellow-400" />
            Platform Integration Guide
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="bg-blue-500 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold">1</span>
              </div>
              <h3 className="font-semibold mb-2">Click Connect</h3>
              <p className="text-gray-300 text-sm">
                Click "Connect [Platform]" to start integration process
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-blue-500 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold">2</span>
              </div>
              <h3 className="font-semibold mb-2">Provide Details</h3>
              <p className="text-gray-300 text-sm">
                Enter your account details or authorize permissions
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-blue-500 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold">3</span>
              </div>
              <h3 className="font-semibold mb-2">Start Sync</h3>
              <p className="text-gray-300 text-sm">
                Platform connects and starts fetching messages
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-blue-500 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold">4</span>
              </div>
              <h3 className="font-semibold mb-2">AI Analysis</h3>
              <p className="text-gray-300 text-sm">
                AI processes messages for emotion analysis and insights
              </p>
            </div>
          </div>
        </div>

        {/* Security & Privacy */}
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20 mb-8">
          <div className="flex items-center mb-4">
            <Shield className="w-6 h-6 text-green-400 mr-2" />
            <h2 className="text-xl font-bold">Security & Privacy</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold mb-2 text-green-400">OAuth2.0 Security</h3>
              <ul className="text-gray-300 text-sm space-y-1">
                <li>• OAuth2.0 with Google/Slack APIs (when configured)</li>
                <li>• Encrypted access tokens in secure storage</li>
                <li>• API calls with proper authentication</li>
                <li>• Revokable OAuth permissions anytime</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-2 text-blue-400">Data Privacy</h3>
              <ul className="text-gray-300 text-sm space-y-1">
                <li>• Read-only access to your messages</li>
                <li>• Message content processed for emotion only</li>
                <li>• Secure processing and analysis</li>
                <li>• GDPR compliant data handling</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Live Data Status */}
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className={`w-3 h-3 rounded-full mr-3 ${connectedCount > 0 ? 'bg-green-400' : 'bg-gray-400'}`} />
              <h2 className="text-xl font-bold">
                {connectedCount > 0 ? '🤖 Real AI Agent Active - Live API Integration' : '⚪ No Real API Integrations'}
              </h2>
            </div>
            <span className="text-sm text-gray-400">
              {connectedCount} of {platforms.length} real APIs connected
            </span>
          </div>
          
          <p className="text-gray-300 mt-2">
            {connectedCount > 0 
              ? `🚀 AI Agent is analyzing emotions from connected platforms! Active: ${connectedPlatforms.map(p => p.charAt(0).toUpperCase() + p.slice(1)).join(', ')}. Messages are processed for emotional insights and patterns.`
              : '🔗 Connect platforms above to activate AI Agent with live message analysis.'
            }
          </p>
          
          {connectedCount > 0 && (
            <div className="mt-4 p-3 bg-green-500/20 border border-green-400/30 rounded-lg">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-green-400 font-medium">🧠 AI Processing Active</span>
              </div>
              <p className="text-green-300 text-sm mt-1">
                Messages are analyzed for emotions, sentiment patterns, and urgency levels.
              </p>
            </div>
          )}
          
          {connectedCount === 0 && (
            <div className="mt-4 p-3 bg-blue-500/20 border border-blue-400/30 rounded-lg">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                <span className="text-blue-400 font-medium">💡 Integration Setup</span>
              </div>
              <p className="text-blue-300 text-sm mt-1">
                Click "Connect [Platform]" above to start integration. AI will analyze messages for emotions and sentiment.
              </p>
            </div>
          )}
        </div>
    </div>
  );
};

export default PlatformIntegration;