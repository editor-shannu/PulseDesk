import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { platformService } from '../../services/platformService';
import { 
  FaceSmileIcon, 
  FaceFrownIcon, 
  ExclamationTriangleIcon,
  HeartIcon,
  ChatBubbleLeftRightIcon,
  BoltIcon,
  CubeTransparentIcon
} from '@heroicons/react/24/outline';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar } from 'recharts';

const DashboardHome: React.FC = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [realMessages, setRealMessages] = useState<any[]>([]);
  const [emotionStats, setEmotionStats] = useState<any>({});
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [connectedPlatforms, setConnectedPlatforms] = useState<string[]>([]);
  
  useEffect(() => {
    const timer = setInterval(() => {
      try {
        setCurrentTime(new Date());
      } catch (err) {
        console.error('❌ DashboardHome: Timer error:', err);
      }
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    // Update real data every 5 seconds
    const updateData = () => {
      try {
        console.log('📊 DashboardHome: Updating dashboard data...');
        const messages = platformService.getMessages();
        const connectedPlatforms = platformService.getConnectedPlatforms();
        console.log('📨 DashboardHome: Messages:', messages.length, 'Connected platforms:', connectedPlatforms);
        
        setConnectedPlatforms(connectedPlatforms);
        
        if (connectedPlatforms.length === 0) {
          console.log('📊 DashboardHome: No platforms connected, clearing all data');
          setRealMessages([]);
          setEmotionStats({});
        } else {
          console.log('📊 DashboardHome: Platforms connected, showing real data');
          setRealMessages(messages.slice(0, 10)); // Show latest 10 messages
          setEmotionStats(platformService.getEmotionStats());
        }
        setIsLoading(false);
        setError(null);
      } catch (err) {
        console.error('❌ DashboardHome: Error updating data:', err);
        setError('Failed to load dashboard data');
        setIsLoading(false);
      }
    };

    updateData();
    const interval = setInterval(updateData, 5000);
    
    // Listen for platform connection updates
    const unsubscribe = platformService.onConnectionUpdate(() => {
      console.log('📊 DashboardHome: Received connection update, refreshing data...');
      updateData();
    });
    
    return () => {
      clearInterval(interval);
      unsubscribe();
    };
  }, []);

  // Error state
  if (error) {
    return (
      <div className="space-y-8">
        <div className="flex items-center justify-center py-20">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-red-400 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <ExclamationTriangleIcon className="w-8 h-8 text-white" />
            </div>
            <p className="text-white text-xl font-semibold mb-2">Dashboard Error</p>
            <p className="text-gray-400 text-sm mb-4">{error}</p>
            <button 
              onClick={() => window.location.reload()}
              className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600"
            >
              Refresh Page
            </button>
          </div>
        </div>
      </div>
    );
  }
  // Show loading state
  if (isLoading) {
    console.log('⏳ DashboardHome: Loading...');
    return (
      <div className="space-y-8">
        <div className="flex items-center justify-center py-20">
          <div className="text-center">
            <motion.div 
              animate={{ rotateY: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              className="w-16 h-16 bg-gradient-to-br from-blue-400 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4"
              style={{ transformStyle: 'preserve-3d' }}
            >
              <CubeTransparentIcon className="w-8 h-8 text-white" />
            </motion.div>
            <p className="text-white text-xl font-semibold">Loading 3D Dashboard...</p>
            <p className="text-gray-400 text-sm mt-2">Initializing emotion analytics...</p>
          </div>
        </div>
      </div>
    );
  }

  console.log('✅ DashboardHome: Loaded successfully with', realMessages.length, 'messages');

  // Safe data processing with error handling
  let emotionData, pieData, barData, stats, recentTickets;
  
  try {
    // Only show data if platforms are connected and have real messages
    const connectedPlatforms = platformService.getConnectedPlatforms();
    const hasConnectedPlatforms = connectedPlatforms.length > 0;
    const hasRealMessages = realMessages.length > 0;
    
    // Enhanced 3D emotion data for visualization - only if connected and has messages
    emotionData = hasConnectedPlatforms && hasRealMessages ? [
      { time: '09:00', positive: 65, negative: 15, neutral: 20, z: 10 },
      { time: '10:00', positive: 70, negative: 18, neutral: 12, z: 15 },
      { time: '11:00', positive: 45, negative: 35, neutral: 20, z: 25 },
      { time: '12PM', positive: 80, negative: 10, neutral: 10, z: 5 },
      { time: '13:00', positive: 55, negative: 25, neutral: 20, z: 20 },
      { time: '14:00', positive: 75, negative: 15, neutral: 10, z: 12 },
    ] : [];

    // 3D Pie chart data with depth - only if connected and has messages
    pieData = hasConnectedPlatforms && hasRealMessages ? [
      { name: 'Happy', value: emotionStats.happy || 0, color: '#10B981', depth: 20 },
      { name: 'Excited', value: emotionStats.excited || 0, color: '#F59E0B', depth: 15 },
      { name: 'Neutral', value: emotionStats.neutral || 0, color: '#6B7280', depth: 10 },
      { name: 'Confused', value: emotionStats.confused || 0, color: '#8B5CF6', depth: 12 },
      { name: 'Frustrated', value: emotionStats.frustrated || 0, color: '#EF4444', depth: 18 },
      { name: 'Angry', value: emotionStats.angry || 0, color: '#DC2626', depth: 25 },
    ].filter(item => item.value > 0) : [];

    // 3D Bar chart data - only if connected and has messages
    barData = hasConnectedPlatforms && hasRealMessages ? [
      { platform: 'Gmail', messages: realMessages.filter(m => m.platform === 'gmail').length, satisfaction: 85 },
      { platform: 'Slack', messages: realMessages.filter(m => m.platform === 'slack').length, satisfaction: 92 },
      { platform: 'Telegram', messages: realMessages.filter(m => m.platform === 'telegram').length, satisfaction: 78 },
    ].filter(item => item.messages > 0) : [];

    stats = [
    {
      name: 'Total Messages Today',
      value: platformService.getTotalMessageCount().toString(),
      change: '+12.5%',
      icon: ChatBubbleLeftRightIcon,
      color: 'from-blue-500 to-cyan-500',
      gradient3d: 'linear-gradient(135deg, #3B82F6, #06B6D4)'
    },
    {
      name: 'Happy Customers',
      value: realMessages.filter(m => m.emotion === 'happy').length.toString(),
      change: '+8.2%',
      icon: FaceSmileIcon,
      color: 'from-green-500 to-emerald-500',
      gradient3d: 'linear-gradient(135deg, #10B981, #059669)'
    },
    {
      name: 'Issues Resolved',
      value: '94.2%',
      change: '+2.1%',
      icon: HeartIcon,
      color: 'from-purple-500 to-pink-500',
      gradient3d: 'linear-gradient(135deg, #8B5CF6, #EC4899)'
    },
    {
      name: 'Alert Triggers',
      value: platformService.getUrgentMessageCount().toString(),
      change: '-15.3%',
      icon: ExclamationTriangleIcon,
      color: 'from-orange-500 to-red-500',
      gradient3d: 'linear-gradient(135deg, #F97316, #EF4444)'
    },
  ];

    // Recent tickets - only if connected and has messages
    recentTickets = hasConnectedPlatforms && hasRealMessages ? realMessages.map(msg => ({
      id: msg.id,
      platform: msg.platform.charAt(0).toUpperCase() + msg.platform.slice(1),
      sender: msg.sender,
      emotion: msg.emotion || 'neutral',
      subject: msg.subject || msg.content.substring(0, 50) + '...',
      time: formatTimeAgo(msg.timestamp)
    })) : [];
  } catch (err) {
    console.error('❌ DashboardHome: Error processing data:', err);
    // Set safe fallback data
    emotionData = [];
    pieData = [];
    barData = [];
    stats = [
      { name: 'Total Messages Today', value: '0', change: '+0%', icon: ChatBubbleLeftRightIcon, color: 'from-blue-500 to-cyan-500', gradient3d: 'linear-gradient(135deg, #3B82F6, #06B6D4)' },
      { name: 'Happy Customers', value: '0', change: '+0%', icon: FaceSmileIcon, color: 'from-green-500 to-emerald-500', gradient3d: 'linear-gradient(135deg, #10B981, #059669)' },
      { name: 'Issues Resolved', value: '0%', change: '+0%', icon: HeartIcon, color: 'from-purple-500 to-pink-500', gradient3d: 'linear-gradient(135deg, #8B5CF6, #EC4899)' },
      { name: 'Alert Triggers', value: '0', change: '+0%', icon: ExclamationTriangleIcon, color: 'from-orange-500 to-red-500', gradient3d: 'linear-gradient(135deg, #F97316, #EF4444)' }
    ];
    recentTickets = [];
  }

  const formatTimeAgo = (date: Date) => {
    try {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
    } catch (err) {
      console.error('❌ DashboardHome: Error formatting time:', err);
      return 'Unknown';
    }
  };

  const getEmotionColor = (emotion: string) => {
    switch (emotion) {
      case 'happy': return 'text-green-400';
      case 'angry': return 'text-red-400';
      case 'confused': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  const getEmotionEmoji = (emotion: string) => {
    switch (emotion) {
      case 'happy': return '😊';
      case 'angry': return '😡';
      case 'confused': return '😕';
      default: return '😐';
    }
  };

  // Safe render with try-catch
  try {
  return (
    <div className="space-y-8">
      {/* Enhanced 3D Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <motion.h1 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="text-4xl font-bold text-white mb-2 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent"
          >
            Welcome back! 👋
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="text-gray-400"
          >
            Here's your 3D emotion analytics dashboard
          </motion.p>
        </div>
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-right"
        >
          <p className="text-sm text-gray-400">Current Time</p>
          <motion.p 
            key={currentTime.toLocaleTimeString()}
            initial={{ scale: 1.1 }}
            animate={{ scale: 1 }}
            className="text-xl font-semibold text-white"
          >
            {currentTime.toLocaleTimeString()}
          </motion.p>
        </motion.div>
      </motion.div>

      {/* Enhanced 3D Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats?.map((stat, index) => (
          <motion.div
            key={stat.name}
            initial={{ opacity: 0, y: 20, rotateX: -15 }}
            animate={{ opacity: 1, y: 0, rotateX: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ 
              scale: 1.05, 
              rotateY: 5,
              boxShadow: "0 25px 50px rgba(0, 0, 0, 0.3)"
            }}
            className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl hover:bg-white/10 transition-all duration-300 relative overflow-hidden"
            style={{
              transformStyle: 'preserve-3d',
              background: `linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05))`
            }}
          >
            {/* 3D Background Effect */}
            <div 
              className="absolute inset-0 opacity-20 rounded-2xl"
              style={{ 
                background: stat.gradient3d,
                transform: 'translateZ(-10px) scale(0.95)'
              }}
            />
            
            <div className="relative z-10 flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400 mb-1">{stat.name}</p>
                <motion.p 
                  initial={{ scale: 0.8 }}
                  animate={{ scale: 1 }}
                  className="text-3xl font-bold text-white"
                >
                  {stat.value}
                </motion.p>
                <p className={`text-sm ${stat.change.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>
                  {stat.change} from yesterday
                </p>
              </div>
              <motion.div 
                whileHover={{ rotateZ: 10, scale: 1.1 }}
                className={`w-14 h-14 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center shadow-lg`}
                style={{ transform: 'translateZ(10px)' }}
              >
                <stat.icon className="w-7 h-7 text-white" />
              </motion.div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Enhanced 3D Charts Section */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* 3D Emotion Trends */}
        <motion.div
          initial={{ opacity: 0, x: -20, rotateY: -10 }}
          animate={{ opacity: 1, x: 0, rotateY: 0 }}
          whileHover={{ rotateY: 2, scale: 1.02 }}
          className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl relative overflow-hidden"
          style={{ transformStyle: 'preserve-3d' }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-2xl transform translateZ(-5px)" />
          <div className="relative z-10">
            <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
              <CubeTransparentIcon className="w-6 h-6 mr-2 text-blue-400" />
              3D Emotion Trends Today
            </h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={emotionData || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="time" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #374151',
                      borderRadius: '12px',
                      color: '#fff',
                      boxShadow: '0 10px 25px rgba(0,0,0,0.3)'
                    }} 
                  />
                  <Line type="monotone" dataKey="positive" stroke="#10B981" strokeWidth={4} dot={{ fill: '#10B981', strokeWidth: 2, r: 6 }} />
                  <Line type="monotone" dataKey="negative" stroke="#EF4444" strokeWidth={4} dot={{ fill: '#EF4444', strokeWidth: 2, r: 6 }} />
                  <Line type="monotone" dataKey="neutral" stroke="#6B7280" strokeWidth={4} dot={{ fill: '#6B7280', strokeWidth: 2, r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </motion.div>

        {/* 3D Platform Performance */}
        <motion.div
          initial={{ opacity: 0, x: 20, rotateY: 10 }}
          animate={{ opacity: 1, x: 0, rotateY: 0 }}
          whileHover={{ rotateY: -2, scale: 1.02 }}
          className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl relative overflow-hidden"
          style={{ transformStyle: 'preserve-3d' }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-pink-500/10 rounded-2xl transform translateZ(-5px)" />
          <div className="relative z-10">
            <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
              <CubeTransparentIcon className="w-6 h-6 mr-2 text-purple-400" />
              3D Platform Analytics
            </h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={barData || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="platform" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #374151',
                      borderRadius: '12px',
                      color: '#fff',
                      boxShadow: '0 10px 25px rgba(0,0,0,0.3)'
                    }} 
                  />
                  <Bar dataKey="messages" fill="url(#messagesGradient)" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="satisfaction" fill="url(#satisfactionGradient)" radius={[4, 4, 0, 0]} />
                  <defs>
                    <linearGradient id="messagesGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#3B82F6" />
                      <stop offset="100%" stopColor="#1D4ED8" />
                    </linearGradient>
                    <linearGradient id="satisfactionGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10B981" />
                      <stop offset="100%" stopColor="#059669" />
                    </linearGradient>
                  </defs>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Enhanced 3D Recent Activity */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        whileHover={{ scale: 1.01 }}
        className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl relative overflow-hidden"
        style={{ transformStyle: 'preserve-3d' }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-blue-500/5 rounded-2xl transform translateZ(-5px)" />
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold text-white flex items-center">
              <CubeTransparentIcon className="w-6 h-6 mr-2 text-cyan-400" />
              3D Live Activity Feed
            </h3>
            <div className="flex items-center space-x-2">
              <motion.div 
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-3 h-3 bg-green-400 rounded-full"
              />
              <span className="text-sm text-gray-400">Live updates</span>
            </div>
          </div>
          
          <div className="space-y-4">
            {recentTickets?.map((ticket, index) => (
              <motion.div
                key={ticket.id}
                initial={{ opacity: 0, x: -20, rotateX: -5 }}
                animate={{ opacity: 1, x: 0, rotateX: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ 
                  scale: 1.02, 
                  rotateY: 2,
                  boxShadow: "0 15px 30px rgba(0, 0, 0, 0.2)"
                }}
                className="flex items-center justify-between p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-all duration-300 relative"
                style={{ transformStyle: 'preserve-3d' }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent rounded-xl transform translateZ(-2px)" />
                
                <div className="relative z-10 flex items-center space-x-4">
                  <motion.span 
                    whileHover={{ scale: 1.2, rotateZ: 10 }}
                    className="text-3xl"
                  >
                    {getEmotionEmoji(ticket.emotion)}
                  </motion.span>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-white font-medium">{ticket.sender}</span>
                      <span className="text-xs bg-blue-500/20 text-blue-300 px-2 py-1 rounded-full">
                        {ticket.platform}
                      </span>
                    </div>
                    <p className="text-gray-300 text-sm">{ticket.subject}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`text-sm font-medium ${getEmotionColor(ticket.emotion)}`}>
                    {ticket.emotion}
                  </p>
                  <p className="text-xs text-gray-400">{ticket.time}</p>
                </div>
              </motion.div>
            )) || []}
            
            {(!recentTickets || recentTickets.length === 0) && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-12"
              >
                <motion.div
                  animate={{ rotateY: 360 }}
                  transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                  className="w-16 h-16 bg-gradient-to-br from-gray-500 to-gray-600 rounded-2xl flex items-center justify-center mx-auto mb-4"
                >
                  <ChatBubbleLeftRightIcon className="w-8 h-8 text-gray-400" />
                </motion.div>
                <p className="text-gray-400 text-lg mb-4">🔗 No platforms connected yet!</p>
                <p className="text-gray-500 text-sm max-w-md mx-auto">
                  Connect Gmail, Slack, or Telegram in Platform Integration to start seeing real-time 3D emotion analytics and AI-powered insights.
                </p>
                {connectedPlatforms.length === 0 ? (
                  <div className="mt-6 p-4 bg-blue-500/20 border border-blue-400/30 rounded-xl max-w-md mx-auto">
                    <p className="text-blue-300 text-sm">
                      💡 <strong>Tip:</strong> Once connected, our AI Agent will analyze message emotions and display beautiful 3D visualizations here!
                    </p>
                  </div>
                ) : (
                  <div className="mt-6 p-4 bg-green-500/20 border border-green-400/30 rounded-xl max-w-md mx-auto">
                    <p className="text-green-300 text-sm">
                      ✅ <strong>Connected:</strong> {connectedPlatforms.join(', ')} - AI Agent is analyzing messages. Data will appear here shortly!
                    </p>
                  </div>
                )}
              </motion.div>
            )}
          </div>
        </div>
      </motion.div>

      {/* Enhanced 3D PulseBot Insights */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        whileHover={{ scale: 1.02, rotateX: 2 }}
        className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-400/20 p-6 rounded-2xl relative overflow-hidden"
        style={{ transformStyle: 'preserve-3d' }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-purple-600/10 to-pink-600/10 rounded-2xl transform translateZ(-5px)" />
        <div className="relative z-10">
          <div className="flex items-center space-x-3 mb-4">
            <motion.div 
              animate={{ rotateZ: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-12 h-12 bg-gradient-to-br from-purple-400 to-pink-600 rounded-xl flex items-center justify-center shadow-lg"
              style={{ transform: 'translateZ(10px)' }}
            >
              <BoltIcon className="w-6 h-6 text-white" />
            </motion.div>
            <h3 className="text-xl font-semibold text-white">3D PulseBot Insights</h3>
          </div>
          <div className="space-y-3">
            {platformService.getConnectedPlatforms().length > 0 && realMessages && realMessages.length > 0 ? (
              <>
                <motion.p 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="text-gray-300"
                >
                  🔍 Analyzing {realMessages.length} real messages with 3D emotion mapping
                </motion.p>
                <motion.p 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 }}
                  className="text-gray-300"
                >
                  📈 {emotionStats.happy || 0}% positive sentiment detected in spatial analysis
                </motion.p>
                <motion.p 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                  className="text-gray-300"
                >
                  {connectedPlatforms.length === 0 
                    ? "🤖 AI Agent is ready! Connect your platforms in Platform Integration to unlock 3D emotion analytics and real-time sentiment monitoring."
                    : `🤖 AI Agent is processing messages from ${connectedPlatforms.join(', ')}. New insights will appear shortly!`
                  }
                </motion.p>
              </>
            ) : (
              <motion.p 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-gray-300"
              >
                🤖 AI Agent is ready! Connect your platforms in Platform Integration to unlock 3D emotion analytics and real-time sentiment monitoring.
              </motion.p>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
  } catch (err) {
    console.error('❌ DashboardHome: Render error:', err);
    return (
      <div className="space-y-8">
        <div className="flex items-center justify-center py-20">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-red-400 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <ExclamationTriangleIcon className="w-8 h-8 text-white" />
            </div>
            <p className="text-white text-xl font-semibold">Render Error</p>
            <p className="text-gray-400 text-sm mt-2">Unable to render dashboard</p>
            <button 
              onClick={() => window.location.reload()}
              className="mt-4 bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600"
            >
              Refresh Page
            </button>
          </div>
        </div>
      </div>
    );
  }
};

export default DashboardHome;