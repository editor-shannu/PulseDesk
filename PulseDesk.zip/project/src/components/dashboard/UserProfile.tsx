import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../../contexts/AuthContext';
import { 
  UserIcon,
  BellIcon,
  ShieldCheckIcon,
  Cog6ToothIcon,
  MoonIcon,
  SunIcon,
  DocumentArrowDownIcon,
  TrashIcon,
  CameraIcon
} from '@heroicons/react/24/outline';
import toast, { Toaster } from 'react-hot-toast';

const UserProfile: React.FC = () => {
  const { user } = useAuth();
  
  // Profile state
  const [fullName, setFullName] = useState(user?.displayName || '');
  const [email, setEmail] = useState(user?.email || '');
  const [company, setCompany] = useState('');
  const [role, setRole] = useState('Support Manager');
  
  // Notification settings
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [slackNotifications, setSlackNotifications] = useState(false);
  const [negativeThreshold, setNegativeThreshold] = useState(25);
  const [responseTimeThreshold, setResponseTimeThreshold] = useState(15);
  
  // Privacy settings
  const [allowAnalytics, setAllowAnalytics] = useState(true);
  const [shareData, setShareData] = useState(false);
  
  // Preferences
  const [darkMode, setDarkMode] = useState(true);
  const [compactMode, setCompactMode] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [language, setLanguage] = useState('English');
  const [timezone, setTimezone] = useState('UTC-8 (Pacific)');

  const handleChangeAvatar = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        // In a real app, you would upload this to a server
        const reader = new FileReader();
        reader.onload = (e) => {
          toast.success('Avatar updated successfully!');
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  const handleSaveProfile = () => {
    // Save profile data
    const profileData = {
      fullName,
      email,
      company,
      role
    };
    
    // In a real app, you would send this to your backend
    localStorage.setItem('pulsedesk_profile', JSON.stringify(profileData));
    toast.success('Profile settings saved successfully!');
  };

  const handleSaveNotifications = () => {
    const notificationSettings = {
      emailNotifications,
      slackNotifications,
      negativeThreshold,
      responseTimeThreshold
    };
    
    localStorage.setItem('pulsedesk_notifications', JSON.stringify(notificationSettings));
    toast.success('Notification settings saved!');
  };

  const handleSavePrivacy = () => {
    const privacySettings = {
      allowAnalytics,
      shareData
    };
    
    localStorage.setItem('pulsedesk_privacy', JSON.stringify(privacySettings));
    toast.success('Privacy settings updated!');
  };

  const handleSavePreferences = () => {
    const preferences = {
      darkMode,
      compactMode,
      autoRefresh,
      language,
      timezone
    };
    
    localStorage.setItem('pulsedesk_preferences', JSON.stringify(preferences));
    toast.success('Preferences saved successfully!');
    
    // Apply dark mode immediately
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const handleExportData = () => {
    // Create a comprehensive data export
    const exportData = {
      profile: { fullName, email, company, role },
      notifications: { emailNotifications, slackNotifications, negativeThreshold, responseTimeThreshold },
      privacy: { allowAnalytics, shareData },
      preferences: { darkMode, compactMode, autoRefresh, language, timezone },
      exportDate: new Date().toISOString()
    };
    
    const dataStr = JSON.stringify(exportData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `pulsedesk-data-export-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    
    URL.revokeObjectURL(url);
    toast.success('Data export downloaded successfully!');
  };

  const handleDeleteAccount = () => {
    const confirmed = window.confirm(
      'Are you sure you want to delete your account? This action cannot be undone and will permanently remove all your data.'
    );
    
    if (confirmed) {
      const doubleConfirm = window.confirm(
        'This is your final warning. Deleting your account will:\n\n' +
        '• Remove all your profile data\n' +
        '• Delete all connected platform integrations\n' +
        '• Permanently erase all message history\n' +
        '• Cancel any active subscriptions\n\n' +
        'Type "DELETE" in the next prompt to confirm.'
      );
      
      if (doubleConfirm) {
        const deleteConfirmation = prompt('Type "DELETE" to confirm account deletion:');
        if (deleteConfirmation === 'DELETE') {
          // Use the platform service to properly delete account
          platformService.deleteAccount()
            .then(() => {
              toast.success('Account deleted successfully. Redirecting...');
              setTimeout(() => {
                window.location.href = '/';
              }, 2000);
            })
            .catch((error) => {
              console.error('Failed to delete account:', error);
              toast.error('Failed to delete account. Please try again.');
            });
        } else {
          toast.error('Account deletion cancelled - confirmation text did not match.');
        }
      }
    }
  };

  const sections = [
    {
      id: 'profile',
      title: 'Profile Information',
      icon: UserIcon,
      content: (
        <div className="space-y-6">
          <div className="flex items-center space-x-6">
            <div className="relative">
              <img 
                src={user?.photoURL || 'https://via.placeholder.com/80'} 
                alt="Profile" 
                className="w-20 h-20 rounded-full border-4 border-white/20"
              />
              <button
                onClick={handleChangeAvatar}
                className="absolute -bottom-2 -right-2 w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center hover:opacity-90 transition-opacity"
              >
                <CameraIcon className="w-4 h-4 text-white" />
              </button>
            </div>
            <div>
              <h4 className="text-white font-semibold">Profile Picture</h4>
              <p className="text-gray-400 text-sm">Click the camera icon to change your avatar</p>
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Full Name</label>
              <input 
                type="text" 
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full bg-white/10 border border-white/20 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white/10 border border-white/20 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Company</label>
              <input 
                type="text" 
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                placeholder="Your company name" 
                className="w-full bg-white/10 border border-white/20 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Role</label>
              <select 
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full bg-white/10 border border-white/20 text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="Support Manager">Support Manager</option>
                <option value="Customer Success">Customer Success</option>
                <option value="Team Lead">Team Lead</option>
                <option value="Administrator">Administrator</option>
                <option value="Agent">Agent</option>
                <option value="Supervisor">Supervisor</option>
              </select>
            </div>
          </div>
          
          <button 
            onClick={handleSaveProfile}
            className="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-6 py-3 rounded-lg hover:opacity-90 transition-opacity font-medium"
          >
            Save Changes
          </button>
        </div>
      )
    },
    {
      id: 'notifications',
      title: 'Notification Settings',
      icon: BellIcon,
      content: (
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-white font-medium">Email Notifications</h4>
                <p className="text-gray-400 text-sm">Receive alerts via email when sentiment spikes</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={emailNotifications} 
                  onChange={(e) => setEmailNotifications(e.target.checked)}
                  className="sr-only peer" 
                />
                <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-white font-medium">Slack Integration</h4>
                <p className="text-gray-400 text-sm">Send notifications to your Slack workspace</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={slackNotifications} 
                  onChange={(e) => setSlackNotifications(e.target.checked)}
                  className="sr-only peer" 
                />
                <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 p-4 rounded-xl">
            <h4 className="text-white font-medium mb-3">Alert Thresholds</h4>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-300 mb-2">
                  Negative Sentiment Alert ({negativeThreshold}%)
                </label>
                <input 
                  type="range" 
                  min="10" 
                  max="50" 
                  value={negativeThreshold}
                  onChange={(e) => setNegativeThreshold(parseInt(e.target.value))}
                  className="w-full accent-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-300 mb-2">
                  Response Time Alert ({responseTimeThreshold} minutes)
                </label>
                <input 
                  type="range" 
                  min="5" 
                  max="60" 
                  value={responseTimeThreshold}
                  onChange={(e) => setResponseTimeThreshold(parseInt(e.target.value))}
                  className="w-full accent-blue-500"
                />
              </div>
            </div>
          </div>
          
          <button 
            onClick={handleSaveNotifications}
            className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-lg hover:opacity-90 transition-opacity font-medium"
          >
            Save Notification Settings
          </button>
        </div>
      )
    },
    {
      id: 'security',
      title: 'Security & Privacy',
      icon: ShieldCheckIcon,
      content: (
        <div className="space-y-6">
          <div className="bg-green-500/20 border border-green-400/30 p-4 rounded-xl">
            <div className="flex items-center space-x-3">
              <ShieldCheckIcon className="w-6 h-6 text-green-400" />
              <div>
                <h4 className="text-green-400 font-medium">Account Secured</h4>
                <p className="text-green-300 text-sm">Your account is protected with Google OAuth</p>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <h4 className="text-white font-medium mb-3">Data Management</h4>
              <div className="space-y-3">
                <button 
                  onClick={handleExportData}
                  className="w-full flex items-center space-x-3 p-4 bg-blue-500/20 border border-blue-400/30 text-blue-300 rounded-xl hover:bg-blue-500/30 transition-all duration-300"
                >
                  <DocumentArrowDownIcon className="w-5 h-5" />
                  <span>Export My Data</span>
                </button>
                <button 
                  onClick={handleDeleteAccount}
                  className="w-full flex items-center space-x-3 p-4 bg-red-500/20 border border-red-400/30 text-red-300 rounded-xl hover:bg-red-500/30 transition-all duration-300"
                >
                  <TrashIcon className="w-5 h-5" />
                  <span>Delete Account</span>
                </button>
              </div>
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 p-4 rounded-xl">
            <h4 className="text-white font-medium mb-3">Privacy Settings</h4>
            <div className="space-y-3">
              <label className="flex items-center space-x-3">
                <input 
                  type="checkbox" 
                  checked={allowAnalytics}
                  onChange={(e) => setAllowAnalytics(e.target.checked)}
                  className="rounded bg-white/10 border-white/20 text-blue-500 focus:ring-blue-500" 
                />
                <span className="text-gray-300">Allow analytics for service improvement</span>
              </label>
              <label className="flex items-center space-x-3">
                <input 
                  type="checkbox" 
                  checked={shareData}
                  onChange={(e) => setShareData(e.target.checked)}
                  className="rounded bg-white/10 border-white/20 text-blue-500 focus:ring-blue-500" 
                />
                <span className="text-gray-300">Share anonymized data for research</span>
              </label>
            </div>
          </div>
          
          <button 
            onClick={handleSavePrivacy}
            className="bg-gradient-to-r from-purple-500 to-pink-600 text-white px-6 py-3 rounded-lg hover:opacity-90 transition-opacity font-medium"
          >
            Save Privacy Settings
          </button>
        </div>
      )
    },
    {
      id: 'preferences',
      title: 'Preferences',
      icon: Cog6ToothIcon,
      content: (
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {darkMode ? <MoonIcon className="w-5 h-5 text-blue-400" /> : <SunIcon className="w-5 h-5 text-yellow-400" />}
                <div>
                  <h4 className="text-white font-medium">Dark Mode</h4>
                  <p className="text-gray-400 text-sm">Switch between light and dark themes</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={darkMode} 
                  onChange={(e) => setDarkMode(e.target.checked)}
                  className="sr-only peer" 
                />
                <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-white font-medium">Compact Mode</h4>
                <p className="text-gray-400 text-sm">Reduce spacing and use smaller components</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={compactMode} 
                  onChange={(e) => setCompactMode(e.target.checked)}
                  className="sr-only peer" 
                />
                <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-white font-medium">Auto Refresh</h4>
                <p className="text-gray-400 text-sm">Automatically refresh dashboard data</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={autoRefresh} 
                  onChange={(e) => setAutoRefresh(e.target.checked)}
                  className="sr-only peer" 
                />
                <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after-border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 p-4 rounded-xl">
            <h4 className="text-white font-medium mb-3">Language & Region</h4>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-300 mb-2">Language</label>
                <select 
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="w-full bg-white/10 border border-white/20 text-white px-3 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="English">English</option>
                  <option value="Spanish">Spanish</option>
                  <option value="French">French</option>
                  <option value="German">German</option>
                  <option value="Japanese">Japanese</option>
                  <option value="Chinese">Chinese</option>
                </select>
              </div>
              <div>
                <label className="block text-sm text-gray-300 mb-2">Time Zone</label>
                <select 
                  value={timezone}
                  onChange={(e) => setTimezone(e.target.value)}
                  className="w-full bg-white/10 border border-white/20 text-white px-3 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="UTC-8 (Pacific)">UTC-8 (Pacific)</option>
                  <option value="UTC-5 (Eastern)">UTC-5 (Eastern)</option>
                  <option value="UTC+0 (GMT)">UTC+0 (GMT)</option>
                  <option value="UTC+1 (CET)">UTC+1 (CET)</option>
                  <option value="UTC+9 (JST)">UTC+9 (JST)</option>
                </select>
              </div>
            </div>
          </div>
          
          <button 
            onClick={handleSavePreferences}
            className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white px-6 py-3 rounded-lg hover:opacity-90 transition-opacity font-medium"
          >
            Save Preferences
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-8">
      <Toaster position="top-right" />
      
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">User Profile Settings</h1>
        <p className="text-gray-400">Manage your account settings, preferences, and security options</p>
      </div>

      {/* Settings Sections */}
      <div className="space-y-8">
        {sections.map((section, index) => (
          <motion.div
            key={section.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl"
          >
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-purple-600 rounded-xl flex items-center justify-center">
                <section.icon className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-2xl font-semibold text-white">{section.title}</h2>
            </div>
            {section.content}
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default UserProfile;