import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { 
  SparklesIcon, 
  BoltIcon, 
  HeartIcon, 
  ChatBubbleLeftRightIcon,
  ShieldCheckIcon,
  ArrowRightIcon,
  CubeTransparentIcon,
  ChartBarIcon,
  UserGroupIcon,
  GlobeAltIcon,
  StarIcon,
  CheckCircleIcon
} from '@heroicons/react/24/outline';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: containerRef });
  
  const y1 = useTransform(scrollYProgress, [0, 1], [0, -100]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, -200]);
  const rotate = useTransform(scrollYProgress, [0, 1], [0, 360]);

  const handleTryForFree = () => {
    navigate('/login');
  };

  const features = [
    {
      icon: HeartIcon,
      title: "Real-Time Emotion Detection",
      description: "Advanced AI analyzes customer emotions in milliseconds, detecting frustration, joy, confusion, and urgency with 95% accuracy",
      gradient: "from-pink-500 to-rose-500"
    },
    {
      icon: BoltIcon,
      title: "Instant Smart Alerts",
      description: "Get notified the moment negative sentiment spikes across any platform - prevent escalations before they happen",
      gradient: "from-yellow-500 to-orange-500"
    },
    {
      icon: ChatBubbleLeftRightIcon,
      title: "Universal Platform Integration",
      description: "Seamlessly connect Gmail, Slack, Telegram, WhatsApp, and 50+ other platforms with one-click setup",
      gradient: "from-blue-500 to-cyan-500"
    },
    {
      icon: ShieldCheckIcon,
      title: "Enterprise Security",
      description: "Bank-level encryption, GDPR compliance, and zero-trust architecture protect your customer data",
      gradient: "from-green-500 to-emerald-500"
    },
    {
      icon: CubeTransparentIcon,
      title: "3D Analytics Dashboard",
      description: "Immersive 3D visualizations reveal hidden patterns in customer emotions and satisfaction trends",
      gradient: "from-purple-500 to-indigo-500"
    },
    {
      icon: ChartBarIcon,
      title: "Predictive Intelligence",
      description: "Machine learning predicts customer churn risk and suggests proactive engagement strategies",
      gradient: "from-teal-500 to-cyan-500"
    }
  ];

  const testimonials = [
    {
      name: "Sarah Chen",
      role: "VP Customer Success",
      company: "TechFlow Inc",
      text: "PulseDesk transformed our support team. We now catch frustrated customers before they churn, increasing retention by 40%.",
      rating: 5,
      avatar: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150"
    },
    {
      name: "Michael Rodriguez",
      role: "Support Director",
      company: "CloudVibe",
      text: "The emotion analytics are incredible. Our response time improved 60% and customer satisfaction scores hit all-time highs.",
      rating: 5,
      avatar: "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150"
    },
    {
      name: "Emily Watson",
      role: "CX Manager",
      company: "StartupHub",
      text: "PulseDesk's AI caught a major issue before it went viral. The proactive alerts saved our reputation and thousands in revenue.",
      rating: 5,
      avatar: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150"
    }
  ];

  const stats = [
    { value: "10,000+", label: "Happy Customers", icon: UserGroupIcon },
    { value: "99.9%", label: "Uptime SLA", icon: ShieldCheckIcon },
    { value: "50+", label: "Integrations", icon: GlobeAltIcon },
    { value: "95%", label: "Accuracy Rate", icon: ChartBarIcon }
  ];

  const pricingPlans = [
    {
      name: "Starter",
      price: "Free",
      description: "Perfect for small teams getting started",
      features: [
        "Up to 1,000 messages/month",
        "Basic emotion detection",
        "2 platform integrations",
        "Email support"
      ],
      gradient: "from-gray-500 to-gray-600",
      popular: false
    },
    {
      name: "Professional",
      price: "$49",
      description: "Ideal for growing support teams",
      features: [
        "Up to 10,000 messages/month",
        "Advanced emotion analytics",
        "Unlimited integrations",
        "Priority support",
        "Custom alerts",
        "Team collaboration"
      ],
      gradient: "from-blue-500 to-purple-600",
      popular: true
    },
    {
      name: "Enterprise",
      price: "Custom",
      description: "For large organizations with complex needs",
      features: [
        "Unlimited messages",
        "White-label solution",
        "Custom AI training",
        "Dedicated success manager",
        "SLA guarantees",
        "Advanced security"
      ],
      gradient: "from-purple-500 to-pink-600",
      popular: false
    }
  ];

  return (
    <div ref={containerRef} className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <motion.div 
          style={{ y: y1 }}
          className="absolute top-0 left-0 w-96 h-96 bg-purple-500/10 rounded-full mix-blend-multiply filter blur-3xl animate-pulse"
        />
        <motion.div 
          style={{ y: y2, rotate }}
          className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full mix-blend-multiply filter blur-3xl"
        />
        <motion.div 
          style={{ y: y1 }}
          className="absolute bottom-0 left-20 w-96 h-96 bg-blue-500/10 rounded-full mix-blend-multiply filter blur-3xl"
        />
      </div>

      {/* Header */}
      <motion.header 
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="relative z-10 p-6"
      >
        <nav className="flex items-center justify-between max-w-7xl mx-auto">
          <motion.div 
            className="flex items-center space-x-3"
            whileHover={{ scale: 1.05 }}
          >
            <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
              <SparklesIcon className="w-7 h-7 text-white" />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              PulseDesk
            </h1>
          </motion.div>
          <motion.button
            onClick={handleTryForFree}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-6 py-3 rounded-full font-semibold shadow-lg"
          >
            Get Started Free
          </motion.button>
        </nav>
      </motion.header>

      {/* Hero Section */}
      <motion.section 
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="relative z-10 text-center py-20 px-6"
      >
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="mb-8"
          >
            <div className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-sm border border-white/20 px-4 py-2 rounded-full text-sm text-white mb-6">
              <SparklesIcon className="w-4 h-4" />
              <span>Powered by Advanced AI & Machine Learning</span>
            </div>
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-6xl md:text-8xl font-bold mb-8 leading-tight"
          >
            <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
              Where AI
            </span>
            <br />
            <span className="text-white">Listens First</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-xl md:text-2xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed"
          >
            Revolutionary emotion-aware customer support that understands feelings, predicts escalations, and delivers empathetic responses with unprecedented accuracy.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-16"
          >
            <motion.button
              onClick={handleTryForFree}
              whileHover={{ scale: 1.05, boxShadow: "0 20px 40px rgba(59, 130, 246, 0.3)" }}
              whileTap={{ scale: 0.95 }}
              className="group bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-10 py-5 rounded-full text-xl font-semibold flex items-center space-x-3 transition-all duration-300 shadow-2xl"
            >
              <span>Start Free Trial</span>
              <ArrowRightIcon className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => window.open('https://youtu.be/1sPQ6yqfhe0?si=7eAnynm2OxQei-Hp', '_blank')}
              className="group bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/20 text-white px-10 py-5 rounded-full text-xl font-semibold flex items-center space-x-3 transition-all duration-300"
            >
              <span>Watch Demo</span>
              <ArrowRightIcon className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
            </motion.button>
          </motion.div>

          {/* Stats */}
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.8 + index * 0.1 }}
                className="text-center"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-gray-400">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </motion.section>

      {/* Features Section */}
      <motion.section 
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="relative z-10 py-32 px-6"
      >
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <motion.h2 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="text-5xl font-bold text-white mb-6"
            >
              Next-Generation Features
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-gray-300 text-xl max-w-2xl mx-auto"
            >
              Powered by cutting-edge AI and designed for the future of customer support
            </motion.p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ 
                  scale: 1.05, 
                  rotateY: 5,
                  boxShadow: "0 25px 50px rgba(0, 0, 0, 0.3)"
                }}
                className="bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-all duration-500 group perspective-1000"
                style={{ transformStyle: 'preserve-3d' }}
              >
                <motion.div 
                  className={`w-16 h-16 bg-gradient-to-br ${feature.gradient} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}
                  whileHover={{ rotateZ: 10 }}
                >
                  <feature.icon className="w-8 h-8 text-white" />
                </motion.div>
                <h3 className="text-2xl font-semibold text-white mb-4">{feature.title}</h3>
                <p className="text-gray-300 leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
          
          {/* New 3D Features Section */}
          <div className="mt-32">
            <motion.h3 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="text-4xl font-bold text-white mb-16 text-center"
            >
              Advanced 3D Features
            </motion.h3>
            
            {/* Live Ticket Simulator */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              whileHover={{ scale: 1.02, rotateY: 2 }}
              className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-400/20 p-8 rounded-3xl mb-12 relative overflow-hidden"
              style={{ transformStyle: 'preserve-3d' }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 to-purple-600/10 rounded-3xl transform translateZ(-5px)" />
              <div className="relative z-10">
                <div className="flex items-center space-x-4 mb-6">
                  <motion.div 
                    animate={{ rotateY: 360 }}
                    transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                    className="w-16 h-16 bg-gradient-to-br from-blue-400 to-purple-600 rounded-2xl flex items-center justify-center"
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    <ChatBubbleLeftRightIcon className="w-8 h-8 text-white" />
                  </motion.div>
                  <div>
                    <h4 className="text-2xl font-bold text-white">Live Ticket Simulator</h4>
                    <p className="text-blue-200">Experience real-time emotion detection in action</p>
                  </div>
                </div>
                <div className="bg-black/20 p-6 rounded-2xl">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                      <span className="text-gray-300">Type a customer support message...</span>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white/5 p-3 rounded-lg">
                        <p className="text-sm text-gray-400">Example:</p>
                        <p className="text-white">"My order is 3 days late and I'm frustrated!"</p>
                      </div>
                      <div className="bg-white/5 p-3 rounded-lg">
                        <p className="text-sm text-gray-400">AI Analysis:</p>
                        <p className="text-red-400">😡 Frustrated (85% confidence)</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Multilingual Emotion AI Demo */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              whileHover={{ scale: 1.02, rotateY: -2 }}
              className="bg-gradient-to-r from-green-500/10 to-teal-500/10 border border-green-400/20 p-8 rounded-3xl mb-12 relative overflow-hidden"
              style={{ transformStyle: 'preserve-3d' }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-teal-600/10 rounded-3xl transform translateZ(-5px)" />
              <div className="relative z-10">
                <div className="flex items-center space-x-4 mb-6">
                  <motion.div 
                    animate={{ rotateX: 360 }}
                    transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
                    className="w-16 h-16 bg-gradient-to-br from-green-400 to-teal-600 rounded-2xl flex items-center justify-center"
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    <GlobeAltIcon className="w-8 h-8 text-white" />
                  </motion.div>
                  <div>
                    <h4 className="text-2xl font-bold text-white">Multilingual Emotion AI Demo</h4>
                    <p className="text-green-200">Understanding emotions across 40+ languages with cosmic precision</p>
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-black/20 p-6 rounded-2xl">
                    <h5 className="text-lg font-semibold text-white mb-4">🌍 Language Matrix</h5>
                    <div className="space-y-3">
                      {[
                        { lang: 'Hindi', confidence: '94%', emoji: '🇮🇳' },
                        { lang: 'Telugu', confidence: '97%', emoji: '🇮🇳' },
                        { lang: 'Spanish', confidence: '92%', emoji: '🇪🇸' },
                        { lang: 'French', confidence: '89%', emoji: '🇫🇷' },
                        { lang: 'Japanese', confidence: '91%', emoji: '🇯🇵' }
                      ].map((item, index) => (
                        <motion.div
                          key={item.lang}
                          initial={{ opacity: 0, x: -20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className="flex items-center justify-between p-2 bg-white/5 rounded-lg"
                        >
                          <div className="flex items-center space-x-2">
                            <span className="text-lg">{item.emoji}</span>
                            <span className="text-white">{item.lang}</span>
                          </div>
                          <span className="text-green-400 font-semibold">{item.confidence}</span>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-black/20 p-6 rounded-2xl">
                    <h5 className="text-lg font-semibold text-white mb-4">Spanish Analysis</h5>
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm text-gray-400">Original Text</p>
                        <p className="text-white italic">"No entiendo cómo funciona esta función."</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Translation</p>
                        <p className="text-gray-300">"I don't understand how this feature works."</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Emotion Analysis</p>
                        <div className="flex items-center space-x-2">
                          <span className="text-2xl">😕</span>
                          <div>
                            <p className="text-yellow-400 font-semibold">Confused</p>
                            <p className="text-sm text-gray-400">Confidence: 91%</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Gamified Agent Leaderboard */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.02, rotateX: 2 }}
              className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-400/20 p-8 rounded-3xl mb-12 relative overflow-hidden"
              style={{ transformStyle: 'preserve-3d' }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-purple-600/10 to-pink-600/10 rounded-3xl transform translateZ(-5px)" />
              <div className="relative z-10">
                <div className="flex items-center space-x-4 mb-6">
                  <motion.div 
                    animate={{ rotateZ: [0, 10, -10, 0] }}
                    transition={{ duration: 3, repeat: Infinity }}
                    className="w-16 h-16 bg-gradient-to-br from-purple-400 to-pink-600 rounded-2xl flex items-center justify-center"
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    <StarIcon className="w-8 h-8 text-white" />
                  </motion.div>
                  <div>
                    <h4 className="text-2xl font-bold text-white">Gamified Agent Leaderboard</h4>
                    <p className="text-purple-200">Level up your support skills with cosmic achievements</p>
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-black/20 p-6 rounded-2xl">
                    <h5 className="text-lg font-semibold text-white mb-4">🏆 Top Agents</h5>
                    <div className="space-y-3">
                      {[
                        { name: 'Alex Chen', score: '2,850', badge: '🥇', streak: 'Hot Streak' },
                        { name: 'Sarah Kim', score: '2,720', badge: '🥈', streak: 'Rising Star' },
                        { name: 'Marcus Johnson', score: '2,650', badge: '🥉', streak: 'Lightning Bolt' },
                        { name: 'Emma Rodriguez', score: '2,530', badge: '🏅', streak: 'Empathy Master' }
                      ].map((agent, index) => (
                        <motion.div
                          key={agent.name}
                          initial={{ opacity: 0, x: -20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.1 }}
                          whileHover={{ scale: 1.05, backgroundColor: 'rgba(255,255,255,0.1)' }}
                          className="flex items-center justify-between p-3 bg-white/5 rounded-lg cursor-pointer transition-all duration-300"
                        >
                          <div className="flex items-center space-x-3">
                            <span className="text-2xl">{agent.badge}</span>
                            <div>
                              <p className="text-white font-semibold">{agent.name}</p>
                              <p className="text-xs text-purple-300">{agent.streak}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-purple-400 font-bold">{agent.score}</p>
                            <p className="text-xs text-gray-400">XP Points</p>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-black/20 p-6 rounded-2xl">
                    <h5 className="text-lg font-semibold text-white mb-4">Weekly Achievements</h5>
                    <div className="grid grid-cols-2 gap-3">
                      {[
                        { icon: '⚡', title: 'Speed Demon', desc: 'Sub 2min response' },
                        { icon: '❤️', title: 'Empathy Master', desc: 'Perfect satisfaction' },
                        { icon: '🎯', title: 'Problem Solver', desc: 'Zero escalations' },
                        { icon: '🌟', title: 'Team Player', desc: 'Helped 5 colleagues' }
                      ].map((achievement, index) => (
                        <motion.div
                          key={achievement.title}
                          initial={{ opacity: 0, scale: 0.8 }}
                          whileInView={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.1 }}
                          whileHover={{ scale: 1.1, rotateZ: 5 }}
                          className="bg-white/5 p-3 rounded-lg text-center cursor-pointer transition-all duration-300"
                        >
                          <div className="text-2xl mb-1">{achievement.icon}</div>
                          <p className="text-white text-sm font-semibold">{achievement.title}</p>
                          <p className="text-xs text-gray-400">{achievement.desc}</p>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Customer Journey Transformation */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              whileHover={{ scale: 1.02, rotateY: 1 }}
              className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-400/20 p-8 rounded-3xl relative overflow-hidden"
              style={{ transformStyle: 'preserve-3d' }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-600/10 to-blue-600/10 rounded-3xl transform translateZ(-5px)" />
              <div className="relative z-10">
                <div className="flex items-center space-x-4 mb-6">
                  <motion.div 
                    animate={{ rotateY: 360, rotateX: 180 }}
                    transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
                    className="w-16 h-16 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-2xl flex items-center justify-center"
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    <UserGroupIcon className="w-8 h-8 text-white" />
                  </motion.div>
                  <div>
                    <h4 className="text-2xl font-bold text-white">The Customer Journey Transformation</h4>
                    <p className="text-cyan-200">Watch how PulseDesk transforms frustration into satisfaction</p>
                  </div>
                </div>
                
                <div className="grid md:grid-cols-4 gap-4 mb-6">
                  {[
                    { stage: 'Frustrated Customer', icon: '😤', color: 'from-red-500 to-pink-500' },
                    { stage: 'AI Analysis', icon: '🤖', color: 'from-purple-500 to-indigo-500' },
                    { stage: 'Empathetic Agent', icon: '👤', color: 'from-blue-500 to-cyan-500' },
                    { stage: 'Satisfied & Happy', icon: '😊', color: 'from-green-500 to-emerald-500' }
                  ].map((step, index) => (
                    <motion.div
                      key={step.stage}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.2 }}
                      whileHover={{ scale: 1.1, rotateY: 10 }}
                      className="text-center"
                    >
                      <motion.div 
                        animate={{ rotateZ: index % 2 === 0 ? [0, 5, -5, 0] : [0, -5, 5, 0] }}
                        transition={{ duration: 2, repeat: Infinity, delay: index * 0.5 }}
                        className={`w-16 h-16 bg-gradient-to-br ${step.color} rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg`}
                      >
                        <span className="text-2xl">{step.icon}</span>
                      </motion.div>
                      <p className="text-white font-semibold text-sm">{step.stage}</p>
                    </motion.div>
                  ))}
                </div>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-black/20 p-6 rounded-2xl">
                    <h5 className="text-lg font-semibold text-white mb-4">🤖 Empowered Agent</h5>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3 p-3 bg-blue-500/20 rounded-lg">
                        <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                          <span className="text-white text-sm">👤</span>
                        </div>
                        <div>
                          <p className="text-white text-sm">Agent receives context and suggested response</p>
                          <p className="text-blue-300 text-xs">Empathy template activated | Manager notified</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="bg-black/20 p-6 rounded-2xl">
                    <h5 className="text-lg font-semibold text-white mb-4">🎯 AI Analysis</h5>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300 text-sm">Empathy template activated</span>
                        <span className="text-green-400 text-sm font-semibold">95%</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <motion.div 
                          initial={{ width: 0 }}
                          whileInView={{ width: '95%' }}
                          transition={{ duration: 2, delay: 0.5 }}
                          className="bg-gradient-to-r from-green-400 to-emerald-500 h-2 rounded-full"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </motion.section>

      {/* Testimonials */}
      <motion.section 
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        className="relative z-10 py-32 px-6"
      >
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <motion.h2 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="text-5xl font-bold text-white mb-6"
            >
              Trusted by Industry Leaders
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-gray-300 text-xl"
            >
              See how teams worldwide are transforming their customer support
            </motion.p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.name}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.2 }}
                whileHover={{ 
                  scale: 1.05,
                  rotateX: 5,
                  boxShadow: "0 25px 50px rgba(0, 0, 0, 0.3)"
                }}
                className="bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-3xl"
              >
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <StarIcon key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-300 text-lg mb-6 italic">"{testimonial.text}"</p>
                <div className="flex items-center">
                  <img 
                    src={testimonial.avatar} 
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full mr-4"
                  />
                  <div>
                    <h4 className="text-white font-semibold">{testimonial.name}</h4>
                    <p className="text-gray-400">{testimonial.role} at {testimonial.company}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>

      {/* Pricing Section */}
      <motion.section 
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        className="relative z-10 py-32 px-6"
      >
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <motion.h2 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="text-5xl font-bold text-white mb-6"
            >
              Simple, Transparent Pricing
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-gray-300 text-xl"
            >
              Choose the perfect plan for your team's needs
            </motion.p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {pricingPlans.map((plan, index) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ 
                  scale: 1.05,
                  rotateY: plan.popular ? 0 : 5
                }}
                className={`bg-white/5 backdrop-blur-sm border border-white/10 p-8 rounded-3xl relative ${
                  plan.popular ? 'ring-2 ring-blue-500 scale-105' : ''
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-full text-sm font-semibold">
                      Most Popular
                    </span>
                  </div>
                )}
                
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                  <div className="text-4xl font-bold text-white mb-2">
                    {plan.price}
                    {plan.price !== 'Free' && plan.price !== 'Custom' && <span className="text-lg text-gray-400">/month</span>}
                  </div>
                  <p className="text-gray-400">{plan.description}</p>
                </div>
                
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-gray-300">
                      <CheckCircleIcon className="w-5 h-5 text-green-400 mr-3 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
                
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleTryForFree}
                  className={`w-full py-4 rounded-xl font-semibold transition-all duration-300 ${
                    plan.popular
                      ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                      : 'bg-white/10 text-white hover:bg-white/20'
                  }`}
                >
                  {plan.price === 'Custom' ? 'Contact Sales' : 'Get Started'}
                </motion.button>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>

      {/* CTA Section */}
      <motion.section 
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        className="relative z-10 py-32 px-6 text-center"
      >
        <div className="max-w-4xl mx-auto">
          <motion.h2 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-5xl font-bold text-white mb-8"
          >
            Ready to Transform Customer Support?
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-300 mb-12"
          >
            Join thousands of teams already using PulseDesk to deliver exceptional customer experiences
          </motion.p>
          <motion.button
            onClick={handleTryForFree}
            whileHover={{ 
              scale: 1.05,
              boxShadow: "0 25px 50px rgba(59, 130, 246, 0.4)"
            }}
            whileTap={{ scale: 0.95 }}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-16 py-6 rounded-full text-2xl font-semibold transition-all duration-300 shadow-2xl"
          >
            Start Your Free Trial Today
          </motion.button>
        </div>
      </motion.section>

      {/* Footer */}
      <footer className="relative z-10 bg-black/20 backdrop-blur-sm border-t border-white/10 py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-purple-600 rounded-xl flex items-center justify-center">
                  <SparklesIcon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white">PulseDesk</h3>
              </div>
              <p className="text-gray-400 mb-6">
                Emotion-aware customer support powered by advanced AI. Created with passion by innovative developers.
              </p>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Integrations</a></li>
                <li><a href="#" className="hover:text-white transition-colors">API</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">About</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Creators</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a 
                    href="https://editor-shannu-portfolio.netlify.app/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="hover:text-blue-400 transition-colors flex items-center space-x-2"
                  >
                    <span>Shanmukh</span>
                    <ArrowRightIcon className="w-4 h-4" />
                  </a>
                </li>
                <li>
                  <a 
                    href="https://ml-portfolio-praveen.lovable.app/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="hover:text-purple-400 transition-colors flex items-center space-x-2"
                  >
                    <span>Praveen</span>
                    <ArrowRightIcon className="w-4 h-4" />
                  </a>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 mb-4 md:mb-0">
              © 2025 PulseDesk. All rights reserved. Created by{' '}
              <a 
                href="https://editor-shannu-portfolio.netlify.app/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-blue-400 hover:text-blue-300 transition-colors"
              >
                Shanmukh
              </a>
              {' '}and{' '}
              <a 
                href="https://ml-portfolio-praveen.lovable.app/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-purple-400 hover:text-purple-300 transition-colors"
              >
                Praveen
              </a>
            </p>
            <div className="flex space-x-6 text-gray-400">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;