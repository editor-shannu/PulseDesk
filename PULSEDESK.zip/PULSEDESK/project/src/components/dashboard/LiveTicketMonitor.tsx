import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { platformService, Message } from '../../services/platformService';
import { 
  BellIcon,
  FaceSmileIcon,
  FaceFrownIcon,
  ExclamationTriangleIcon,
  ClockIcon,
  ChatBubbleLeftRightIcon
} from '@heroicons/react/24/outline';

const LiveTicketMonitor: React.FC = () => {
  const [tickets, setTickets] = useState<Message[]>([]);
  const [filter, setFilter] = useState('all');

  // Load real tickets from platform service
  useEffect(() => {

    const updateTickets = () => {
      const messages = platformService.getMessages();
      setTickets(messages);
    };

    updateTickets();
    const interval = setInterval(updateTickets, 5000); // Update every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const getEmotionColor = (emotion: string) => {
    switch (emotion) {
      case 'happy': return 'text-green-400 bg-green-400/20';
      case 'angry': return 'text-red-400 bg-red-400/20';
      case 'frustrated': return 'text-orange-400 bg-orange-400/20';
      case 'confused': return 'text-yellow-400 bg-yellow-400/20';
      default: return 'text-gray-400 bg-gray-400/20';
    }
  };

  const getEmotionIcon = (emotion: string) => {
    switch (emotion) {
      case 'happy': return FaceSmileIcon;
      case 'angry':
      case 'frustrated':
        return FaceFrownIcon;
      case 'confused': return ExclamationTriangleIcon;
      default: return ChatBubbleLeftRightIcon;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'border-l-red-500 bg-red-500/10';
      case 'high': return 'border-l-orange-500 bg-orange-500/10';
      case 'medium': return 'border-l-yellow-500 bg-yellow-500/10';
      default: return 'border-l-gray-500 bg-gray-500/10';
    }
  };

  const filteredTickets = tickets.filter(ticket => {
    if (filter === 'all') return true;
    return ticket.emotion === filter;
  });

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Live Ticket Monitor</h1>
          <p className="text-gray-400">Real-time customer support ticket monitoring with emotion analysis</p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-sm text-gray-400">Live Feed Active</span>
        </div>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {[
          { label: 'Total', value: tickets.length, color: 'from-blue-500 to-cyan-500' },
          { label: 'Happy', value: tickets.filter(t => t.emotion === 'happy').length, color: 'from-green-500 to-emerald-500' },
          { label: 'Angry', value: tickets.filter(t => t.emotion === 'angry').length, color: 'from-red-500 to-pink-500' },
          { label: 'Confused', value: tickets.filter(t => t.emotion === 'confused').length, color: 'from-yellow-500 to-orange-500' },
          { label: 'Urgent', value: tickets.filter(t => t.priority === 'urgent').length, color: 'from-purple-500 to-indigo-500' },
        ].map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white/5 backdrop-blur-sm border border-white/10 p-4 rounded-xl text-center"
          >
            <div className={`w-8 h-8 bg-gradient-to-br ${stat.color} rounded-lg mx-auto mb-2`}></div>
            <p className="text-2xl font-bold text-white">{stat.value}</p>
            <p className="text-sm text-gray-400">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      {/* Filter Buttons */}
      <div className="flex flex-wrap gap-2">
        {['all', 'happy', 'neutral', 'confused', 'angry', 'frustrated'].map((emotion) => (
          <button
            key={emotion}
            onClick={() => setFilter(emotion)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
              filter === emotion
                ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                : 'bg-white/10 text-gray-300 hover:bg-white/20'
            }`}
          >
            {emotion.charAt(0).toUpperCase() + emotion.slice(1)}
          </button>
        ))}
      </div>

      {/* Tickets List */}
      <div className="space-y-4">
        <motion.div layout className="space-y-4">
          {filteredTickets.map((ticket, index) => {
            const EmotionIcon = getEmotionIcon(ticket.emotion);
            
            return (
              <motion.div
                key={ticket.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                layout
                className={`bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl overflow-hidden hover:bg-white/10 transition-all duration-300 border-l-4 ${getPriorityColor(ticket.priority || 'low')}`}
              >
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-4">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${getEmotionColor(ticket.emotion)}`}>
                        <EmotionIcon className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-3">
                          <h3 className="text-lg font-semibold text-white">{ticket.sender}</h3>
                          <span className="text-xs bg-blue-500/20 text-blue-300 px-2 py-1 rounded-full">
                            {ticket.platform.charAt(0).toUpperCase() + ticket.platform.slice(1)}
                          </span>
                          <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                            ticket.priority === 'urgent' ? 'bg-red-500/20 text-red-300' :
                            ticket.priority === 'high' ? 'bg-orange-500/20 text-orange-300' :
                            ticket.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-300' :
                            'bg-gray-500/20 text-gray-300'
                          }`}>
                            {ticket.priority || 'low'}
                          </span>
                        </div>
                        <p className="text-gray-300 font-medium">{ticket.subject || 'Message'}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`inline-flex items-center space-x-2 px-3 py-1 rounded-full text-sm font-medium ${getEmotionColor(ticket.emotion || 'neutral')}`}>
                        <span>{ticket.emotion || 'neutral'}</span>
                        <span className="text-xs">({((ticket.confidence || 0.5) * 100).toFixed(0)}%)</span>
                      </div>
                      <div className="flex items-center space-x-1 text-gray-400 text-sm mt-2">
                        <ClockIcon className="w-4 h-4" />
                        <span>{formatTimeAgo(ticket.timestamp)}</span>
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-gray-300 mb-4 line-clamp-2">{ticket.content}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex space-x-2">
                      <button className="px-4 py-2 bg-blue-500/20 text-blue-300 rounded-lg hover:bg-blue-500/30 transition-all duration-300">
                        Reply
                      </button>
                      <button className="px-4 py-2 bg-green-500/20 text-green-300 rounded-lg hover:bg-green-500/30 transition-all duration-300">
                        Resolve
                      </button>
                      <button className="px-4 py-2 bg-yellow-500/20 text-yellow-300 rounded-lg hover:bg-yellow-500/30 transition-all duration-300">
                        Escalate
                      </button>
                    </div>
                    <button className="p-2 text-gray-400 hover:text-white transition-colors">
                      <BellIcon className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {filteredTickets.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <ChatBubbleLeftRightIcon className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400 text-lg">
              {tickets.length === 0 
                ? "No messages yet. Connect your platforms to see real-time tickets!" 
                : "No tickets match the current filter"
              }
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default LiveTicketMonitor;