import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  EnvelopeIcon,
  ChatBubbleLeftRightIcon,
  PaperAirplaneIcon,
  CheckCircleIcon,
  XCircleIcon,
  ArrowPathIcon
} from '@heroicons/react/24/outline';
import { platformService, PlatformConnection } from '../../services/platformService';
import toast from 'react-hot-toast';

const PlatformIntegration: React.FC = () => {
  const [connections, setConnections] = useState<Record<string, PlatformConnection>>({});
  const [loading, setLoading] = useState<Record<string, boolean>>({});

  const platforms = [
    {
      id: 'gmail',
      name: 'Gmail',
      description: 'Connect your Gmail account to analyze email sentiment and customer emotions',
      icon: EnvelopeIcon,
      color: 'from-red-500 to-pink-500'
    },
    {
      id: 'slack',
      name: 'Slack',
      description: 'Monitor Slack channels for customer support conversations',
      icon: ChatBubbleLeftRightIcon,
      color: 'from-purple-500 to-indigo-500'
    },
    {
      id: 'telegram',
      name: 'Telegram',
      description: 'Integrate with Telegram bot for real-time customer support',
      icon: PaperAirplaneIcon,
      color: 'from-blue-500 to-cyan-500'
    }
  ];

  useEffect(() => {
    // Load existing connections
    const loadConnections = () => {
      const newConnections: Record<string, PlatformConnection> = {};
      platforms.forEach(platform => {
        const connection = platformService.getConnection(platform.id);
        if (connection) {
          newConnections[platform.id] = connection;
        } else {
          newConnections[platform.id] = {
            platform: platform.id as any,
            connected: false,
            messageCount: 0
          };
        }
      });
      setConnections(newConnections);
    };

    loadConnections();
    
    // Refresh connections every 2 seconds for real-time updates
    const interval = setInterval(loadConnections, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleConnect = async (platformId: string) => {
    setLoading(prev => ({ ...prev, [platformId]: true }));
    
    try {
      switch (platformId) {
        case 'gmail':
          await platformService.connectGmail();
          toast.success('Gmail connected successfully!');
          break;
        case 'slack':
          await platformService.connectSlack();
          toast.success('Slack connected successfully!');
          break;
        case 'telegram':
          await platformService.connectTelegram();
          toast.success('Telegram connected successfully!');
          break;
      }
      
      // Refresh connection status
      const connection = platformService.getConnection(platformId);
      if (connection) {
        setConnections(prev => ({ ...prev, [platformId]: connection }));
      }
    } catch (error) {
      console.error(`Failed to connect ${platformId}:`, error);
      toast.error(`Failed to connect ${platformId}. Please try again.`);
    } finally {
      setLoading(prev => ({ ...prev, [platformId]: false }));
    }
  };

  const handleDisconnect = (platformId: string) => {
    platformService.disconnect(platformId);
    setConnections(prev => ({
      ...prev,
      [platformId]: {
        platform: platformId as any,
        connected: false,
        messageCount: 0
      }
    }));
    toast.success(`${platformId} disconnected successfully!`);
  };

  const handleSync = async (platformId: string) => {
    setLoading(prev => ({ ...prev, [platformId]: true }));
    
    try {
      // Force a sync by reconnecting
      await handleConnect(platformId);
      toast.success(`${platformId} synced successfully!`);
    } catch (error) {
      toast.error(`Failed to sync ${platformId}`);
    } finally {
      setLoading(prev => ({ ...prev, [platformId]: false }));
    }
  };

  const formatLastSync = (date?: Date) => {
    if (!date) return 'Never';
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Platform Integration Hub</h1>
        <p className="text-gray-400">Connect your customer support platforms to enable real-time emotion analysis</p>
      </div>

      {/* Integration Cards */}
      <div className="grid lg:grid-cols-3 gap-6">
        {platforms.map((platform, index) => {
          const connection = connections[platform.id];
          const isLoading = loading[platform.id];
          
          return (
            <motion.div
              key={platform.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl hover:bg-white/10 transition-all duration-300"
            >
              <div className="flex items-center space-x-4 mb-6">
                <div className={`w-12 h-12 bg-gradient-to-br ${platform.color} rounded-xl flex items-center justify-center`}>
                  <platform.icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-white">{platform.name}</h3>
                  <div className="flex items-center space-x-2 mt-1">
                    {connection?.connected && (
                      <div className="flex items-center space-x-1">
                        <CheckCircleIcon className="w-4 h-4 text-green-400" />
                        <span className="text-sm text-green-400">Connected</span>
                      </div>
                    )}
                    {!connection?.connected && (
                      <div className="flex items-center space-x-1">
                        <XCircleIcon className="w-4 h-4 text-gray-400" />
                        <span className="text-sm text-gray-400">Not Connected</span>
                      </div>
                    )}
                    {isLoading && (
                      <div className="flex items-center space-x-1">
                        <ArrowPathIcon className="w-4 h-4 text-blue-400 animate-spin" />
                        <span className="text-sm text-blue-400">Connecting...</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <p className="text-gray-300 text-sm mb-6">{platform.description}</p>

              {/* Stats */}
              {connection?.connected && (
                <div className="bg-white/5 border border-white/10 p-4 rounded-xl mb-6">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-400">Messages Processed</span>
                    <span className="text-lg font-semibold text-white">{connection.messageCount}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">Last Sync</span>
                    <span className="text-sm text-white">{formatLastSync(connection.lastSync)}</span>
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex space-x-3">
                {!connection?.connected ? (
                  <button
                    onClick={() => handleConnect(platform.id)}
                    disabled={isLoading}
                    className={`flex-1 bg-gradient-to-r ${platform.color} hover:opacity-90 text-white py-3 px-4 rounded-xl font-medium transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed`}
                  >
                    {isLoading ? (
                      <div className="flex items-center justify-center space-x-2">
                        <ArrowPathIcon className="w-4 h-4 animate-spin" />
                        <span>Connecting...</span>
                      </div>
                    ) : (
                      `Connect ${platform.name}`
                    )}
                  </button>
                ) : (
                  <>
                    <button
                      onClick={() => handleSync(platform.id)}
                      disabled={isLoading}
                      className="flex-1 bg-white/10 hover:bg-white/20 text-white py-3 px-4 rounded-xl font-medium transition-all duration-300 disabled:opacity-50"
                    >
                      {isLoading ? (
                        <div className="flex items-center justify-center space-x-2">
                          <ArrowPathIcon className="w-4 h-4 animate-spin" />
                          <span>Syncing...</span>
                        </div>
                      ) : (
                        'Sync Now'
                      )}
                    </button>
                    <button
                      onClick={() => handleDisconnect(platform.id)}
                      className="px-4 py-3 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-xl font-medium transition-all duration-300"
                    >
                      Disconnect
                    </button>
                  </>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Integration Guide */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-400/20 p-6 rounded-2xl"
      >
        <h3 className="text-xl font-semibold text-white mb-4">Integration Guide</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-3">
              <span className="text-white font-bold">1</span>
            </div>
            <h4 className="font-semibold text-white mb-2">Connect Platform</h4>
            <p className="text-gray-300 text-sm">Authorize PulseDesk to access your customer support platforms</p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-3">
              <span className="text-white font-bold">2</span>
            </div>
            <h4 className="font-semibold text-white mb-2">Sync Messages</h4>
            <p className="text-gray-300 text-sm">Import existing conversations and set up real-time monitoring</p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-3">
              <span className="text-white font-bold">3</span>
            </div>
            <h4 className="font-semibold text-white mb-2">Monitor Emotions</h4>
            <p className="text-gray-300 text-sm">Get real-time emotion analysis and sentiment alerts</p>
          </div>
        </div>
      </motion.div>

      {/* Live Data Status */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-green-500/10 border border-green-400/20 p-6 rounded-2xl"
      >
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
          <h3 className="text-xl font-semibold text-white">Live Data Integration Active</h3>
        </div>
        <p className="text-green-200">
          All connected platforms are now feeding real data into your emotion analysis dashboard. 
          Messages are automatically synced every 30 seconds and analyzed for emotional content.
        </p>
      </motion.div>
    </div>
  );
};

export default PlatformIntegration;