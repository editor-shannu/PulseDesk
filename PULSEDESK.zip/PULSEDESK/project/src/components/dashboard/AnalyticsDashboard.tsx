import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { platformService } from '../../services/platformService';
import { 
  ChartBarIcon,
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
  UsersIcon,
  ChatBubbleLeftRightIcon,
  ExclamationTriangleIcon,
  CheckCircleIcon,
  CubeTransparentIcon
} from '@heroicons/react/24/outline';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, AreaChart, Area, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

const COLORS = ['#10B981', '#EF4444', '#6B7280', '#F59E0B', '#8B5CF6', '#06B6D4'];

interface EmotionData {
  name: string;
  value: number;
  color: string;
  depth: number;
}

interface PlatformStats {
  platform: string;
  messages: number;
  avgSentiment: number;
  responseTime: string;
  satisfaction: number;
}

const AnalyticsDashboard: React.FC = () => {
  const [emotionData, setEmotionData] = useState<EmotionData[]>([]);
  const [platformStats, setPlatformStats] = useState<PlatformStats[]>([]);
  const [totalMessages, setTotalMessages] = useState(0);
  const [avgSentiment, setAvgSentiment] = useState(0);
  const [activeIssues, setActiveIssues] = useState(0);
  const [resolvedToday, setResolvedToday] = useState(0);

  useEffect(() => {
    const updateAnalytics = () => {
      const allMessages = platformService.getAllMessages();
      
      // Calculate emotion distribution with 3D depth
      const emotions = { happy: 0, angry: 0, neutral: 0, confused: 0, frustrated: 0, excited: 0 };
      let totalSentiment = 0;
      let urgentCount = 0;
      let resolvedCount = 0;

      allMessages.forEach(message => {
        const emotion = message.emotion || 'neutral';
        if (emotions.hasOwnProperty(emotion)) {
          emotions[emotion as keyof typeof emotions]++;
        }
        
        // Calculate sentiment score
        const sentimentScore = emotion === 'happy' || emotion === 'excited' ? 1 : 
                              emotion === 'angry' || emotion === 'frustrated' ? -1 : 0;
        totalSentiment += sentimentScore;
        
        if (message.priority === 'urgent') urgentCount++;
        if (emotion === 'happy' || emotion === 'excited') resolvedCount++;
      });

      const emotionChartData: EmotionData[] = [
        { name: 'Happy', value: emotions.happy, color: '#10B981', depth: 25 },
        { name: 'Excited', value: emotions.excited, color: '#F59E0B', depth: 20 },
        { name: 'Neutral', value: emotions.neutral, color: '#6B7280', depth: 10 },
        { name: 'Confused', value: emotions.confused, color: '#8B5CF6', depth: 15 },
        { name: 'Frustrated', value: emotions.frustrated, color: '#EF4444', depth: 18 },
        { name: 'Angry', value: emotions.angry, color: '#DC2626', depth: 30 }
      ].filter(item => item.value > 0);

      // Calculate platform statistics with satisfaction scores
      const platforms = ['gmail', 'slack', 'telegram'];
      const platformData: PlatformStats[] = platforms.map(platform => {
        const platformMessages = allMessages.filter(m => m.platform === platform);
        const avgSent = platformMessages.length > 0 
          ? platformMessages.reduce((acc, m) => {
              const emotion = m.emotion || 'neutral';
              return acc + (emotion === 'happy' || emotion === 'excited' ? 1 : emotion === 'angry' || emotion === 'frustrated' ? -1 : 0);
            }, 0) / platformMessages.length
          : 0;
        
        const satisfaction = Math.max(0, Math.min(100, 50 + (avgSent * 25) + Math.random() * 20));
        
        return {
          platform: platform.charAt(0).toUpperCase() + platform.slice(1),
          messages: platformMessages.length,
          avgSentiment: Math.round(avgSent * 100) / 100,
          responseTime: `${Math.floor(Math.random() * 5) + 1}m`,
          satisfaction: Math.round(satisfaction)
        };
      }).filter(p => p.messages > 0);

      setEmotionData(emotionChartData);
      setPlatformStats(platformData);
      setTotalMessages(allMessages.length);
      setAvgSentiment(Math.round((totalSentiment / Math.max(allMessages.length, 1)) * 100) / 100);
      setActiveIssues(urgentCount);
      setResolvedToday(resolvedCount);
    };

    updateAnalytics();
    const interval = setInterval(updateAnalytics, 5000);
    return () => clearInterval(interval);
  }, []);

  // Enhanced 3D trend data
  const trendData = [
    { time: '9AM', messages: 12, sentiment: 0.2, satisfaction: 85, depth: 10 },
    { time: '10AM', messages: 19, sentiment: 0.4, satisfaction: 88, depth: 15 },
    { time: '11AM', messages: 15, sentiment: -0.1, satisfaction: 82, depth: 8 },
    { time: '12PM', messages: 25, sentiment: 0.3, satisfaction: 90, depth: 20 },
    { time: '1PM', messages: 22, sentiment: 0.1, satisfaction: 87, depth: 12 },
    { time: '2PM', messages: 18, sentiment: 0.5, satisfaction: 92, depth: 18 },
    { time: '3PM', messages: 30, sentiment: -0.2, satisfaction: 78, depth: 25 }
  ];

  // 3D Radar chart data for emotion analysis
  const radarData = [
    { emotion: 'Happy', current: emotionData.find(e => e.name === 'Happy')?.value || 0, target: 80, fullMark: 100 },
    { emotion: 'Excited', current: emotionData.find(e => e.name === 'Excited')?.value || 0, target: 60, fullMark: 100 },
    { emotion: 'Neutral', current: emotionData.find(e => e.name === 'Neutral')?.value || 0, target: 40, fullMark: 100 },
    { emotion: 'Confused', current: emotionData.find(e => e.name === 'Confused')?.value || 0, target: 20, fullMark: 100 },
    { emotion: 'Frustrated', current: emotionData.find(e => e.name === 'Frustrated')?.value || 0, target: 15, fullMark: 100 },
    { emotion: 'Angry', current: emotionData.find(e => e.name === 'Angry')?.value || 0, target: 5, fullMark: 100 }
  ];

  return (
    <div className="space-y-8">
      {/* Enhanced 3D Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <motion.h1 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="text-4xl font-bold text-white mb-2 bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent"
          >
            3D Analytics Dashboard
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="text-gray-400"
          >
            Immersive insights from your connected platforms
          </motion.p>
        </div>
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-right"
        >
          <p className="text-sm text-gray-400">Last updated</p>
          <p className="text-white font-semibold">{new Date().toLocaleTimeString()}</p>
        </motion.div>
      </motion.div>

      {/* Enhanced 3D KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          {
            title: 'Total Messages',
            value: totalMessages,
            change: '+12%',
            icon: ChatBubbleLeftRightIcon,
            gradient: 'from-blue-500 to-cyan-500',
            bgGradient: 'linear-gradient(135deg, #3B82F6, #06B6D4)'
          },
          {
            title: 'Avg Sentiment',
            value: avgSentiment > 0 ? `+${avgSentiment}` : avgSentiment.toString(),
            change: avgSentiment >= 0 ? 'Positive trend' : 'Needs attention',
            icon: UsersIcon,
            gradient: 'from-purple-500 to-pink-500',
            bgGradient: 'linear-gradient(135deg, #8B5CF6, #EC4899)'
          },
          {
            title: 'Active Issues',
            value: activeIssues,
            change: '-3 from yesterday',
            icon: ExclamationTriangleIcon,
            gradient: 'from-yellow-500 to-orange-500',
            bgGradient: 'linear-gradient(135deg, #F59E0B, #F97316)'
          },
          {
            title: 'Resolved Today',
            value: resolvedToday,
            change: '+8% resolution rate',
            icon: CheckCircleIcon,
            gradient: 'from-green-500 to-emerald-500',
            bgGradient: 'linear-gradient(135deg, #10B981, #059669)'
          }
        ].map((kpi, index) => (
          <motion.div
            key={kpi.title}
            initial={{ opacity: 0, y: 20, rotateX: -15 }}
            animate={{ opacity: 1, y: 0, rotateX: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ 
              scale: 1.05, 
              rotateY: 5,
              boxShadow: "0 25px 50px rgba(0, 0, 0, 0.3)"
            }}
            className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl relative overflow-hidden"
            style={{ transformStyle: 'preserve-3d' }}
          >
            {/* 3D Background Layer */}
            <div 
              className="absolute inset-0 opacity-20 rounded-2xl"
              style={{ 
                background: kpi.bgGradient,
                transform: 'translateZ(-10px) scale(0.95)'
              }}
            />
            
            <div className="relative z-10 flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">{kpi.title}</p>
                <motion.p 
                  initial={{ scale: 0.8 }}
                  animate={{ scale: 1 }}
                  className="text-3xl font-bold text-white"
                >
                  {kpi.value}
                </motion.p>
              </div>
              <motion.div 
                whileHover={{ rotateZ: 10, scale: 1.1 }}
                className={`w-14 h-14 bg-gradient-to-br ${kpi.gradient} rounded-xl flex items-center justify-center shadow-lg`}
                style={{ transform: 'translateZ(10px)' }}
              >
                <kpi.icon className="w-7 h-7 text-white" />
              </motion.div>
            </div>
            <div className="flex items-center mt-2">
              {kpi.change.includes('+') || kpi.change.includes('Positive') ? (
                <ArrowTrendingUpIcon className="w-4 h-4 text-green-500 mr-1" />
              ) : (
                <ArrowTrendingDownIcon className="w-4 h-4 text-red-500 mr-1" />
              )}
              <span className={`text-sm ${kpi.change.includes('+') || kpi.change.includes('Positive') ? 'text-green-500' : 'text-red-500'}`}>
                {kpi.change}
              </span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Enhanced 3D Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* 3D Emotion Distribution */}
        <motion.div
          initial={{ opacity: 0, x: -20, rotateY: -10 }}
          animate={{ opacity: 1, x: 0, rotateY: 0 }}
          whileHover={{ rotateY: 2, scale: 1.02 }}
          className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl relative overflow-hidden"
          style={{ transformStyle: 'preserve-3d' }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-pink-500/10 rounded-2xl transform translateZ(-5px)" />
          <div className="relative z-10">
            <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
              <CubeTransparentIcon className="w-6 h-6 mr-2 text-purple-400" />
              3D Emotion Distribution
            </h3>
            {emotionData.length > 0 ? (
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={emotionData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={90}
                      innerRadius={40}
                      fill="#8884d8"
                      dataKey="value"
                      stroke="#1F2937"
                      strokeWidth={2}
                    >
                      {emotionData.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={entry.color}
                          style={{
                            filter: `drop-shadow(0 ${entry.depth}px ${entry.depth * 2}px rgba(0,0,0,0.3))`
                          }}
                        />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#1F2937', 
                        border: '1px solid #374151',
                        borderRadius: '12px',
                        color: '#F9FAFB',
                        boxShadow: '0 10px 25px rgba(0,0,0,0.3)'
                      }} 
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-64 flex items-center justify-center">
                <motion.div
                  animate={{ rotateY: 360 }}
                  transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                  className="text-center"
                >
                  <CubeTransparentIcon className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">Connect platforms to see 3D emotion insights</p>
                </motion.div>
              </div>
            )}
          </div>
        </motion.div>

        {/* 3D Sentiment Trends */}
        <motion.div
          initial={{ opacity: 0, x: 20, rotateY: 10 }}
          animate={{ opacity: 1, x: 0, rotateY: 0 }}
          whileHover={{ rotateY: -2, scale: 1.02 }}
          className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl relative overflow-hidden"
          style={{ transformStyle: 'preserve-3d' }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-2xl transform translateZ(-5px)" />
          <div className="relative z-10">
            <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
              <CubeTransparentIcon className="w-6 h-6 mr-2 text-cyan-400" />
              3D Sentiment & Satisfaction Trends
            </h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="time" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #374151',
                      borderRadius: '12px',
                      color: '#F9FAFB',
                      boxShadow: '0 10px 25px rgba(0,0,0,0.3)'
                    }} 
                  />
                  <Area 
                    type="monotone" 
                    dataKey="satisfaction" 
                    stackId="1"
                    stroke="#06B6D4" 
                    fill="url(#satisfactionGradient)"
                    strokeWidth={3}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="messages" 
                    stackId="2"
                    stroke="#10B981" 
                    fill="url(#messagesGradient)"
                    strokeWidth={3}
                  />
                  <defs>
                    <linearGradient id="satisfactionGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#06B6D4" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#06B6D4" stopOpacity={0.1}/>
                    </linearGradient>
                    <linearGradient id="messagesGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10B981" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#10B981" stopOpacity={0.1}/>
                    </linearGradient>
                  </defs>
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </motion.div>
      </div>

      {/* 3D Radar Chart for Emotion Analysis */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        whileHover={{ scale: 1.02, rotateX: 2 }}
        className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl relative overflow-hidden"
        style={{ transformStyle: 'preserve-3d' }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 to-purple-500/10 rounded-2xl transform translateZ(-5px)" />
        <div className="relative z-10">
          <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
            <CubeTransparentIcon className="w-6 h-6 mr-2 text-indigo-400" />
            3D Emotion Radar Analysis
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid stroke="#374151" />
                <PolarAngleAxis dataKey="emotion" tick={{ fill: '#9CA3AF', fontSize: 12 }} />
                <PolarRadiusAxis 
                  angle={90} 
                  domain={[0, 100]} 
                  tick={{ fill: '#9CA3AF', fontSize: 10 }}
                />
                <Radar
                  name="Current"
                  dataKey="current"
                  stroke="#06B6D4"
                  fill="#06B6D4"
                  fillOpacity={0.3}
                  strokeWidth={3}
                  dot={{ fill: '#06B6D4', strokeWidth: 2, r: 4 }}
                />
                <Radar
                  name="Target"
                  dataKey="target"
                  stroke="#10B981"
                  fill="#10B981"
                  fillOpacity={0.1}
                  strokeWidth={2}
                  strokeDasharray="5 5"
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '12px',
                    color: '#F9FAFB',
                    boxShadow: '0 10px 25px rgba(0,0,0,0.3)'
                  }} 
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </motion.div>

      {/* Enhanced 3D Platform Performance */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        whileHover={{ scale: 1.01 }}
        className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl relative overflow-hidden"
        style={{ transformStyle: 'preserve-3d' }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-emerald-500/5 rounded-2xl transform translateZ(-5px)" />
        <div className="relative z-10">
          <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
            <CubeTransparentIcon className="w-6 h-6 mr-2 text-green-400" />
            3D Platform Performance Matrix
          </h3>
          {platformStats.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-gray-700">
                    <th className="pb-3 text-gray-400 font-medium">Platform</th>
                    <th className="pb-3 text-gray-400 font-medium">Messages</th>
                    <th className="pb-3 text-gray-400 font-medium">Avg Sentiment</th>
                    <th className="pb-3 text-gray-400 font-medium">Response Time</th>
                    <th className="pb-3 text-gray-400 font-medium">Satisfaction</th>
                    <th className="pb-3 text-gray-400 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {platformStats.map((platform, index) => (
                    <motion.tr 
                      key={index} 
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      whileHover={{ 
                        backgroundColor: 'rgba(255,255,255,0.05)',
                        scale: 1.02,
                        boxShadow: '0 5px 15px rgba(0,0,0,0.2)'
                      }}
                      className="border-b border-gray-700 transition-all duration-300"
                    >
                      <td className="py-4 text-white font-medium">{platform.platform}</td>
                      <td className="py-4 text-gray-300">
                        <motion.span
                          initial={{ scale: 0.8 }}
                          animate={{ scale: 1 }}
                          className="inline-flex items-center px-2 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm"
                        >
                          {platform.messages}
                        </motion.span>
                      </td>
                      <td className="py-4">
                        <span className={`font-semibold ${platform.avgSentiment >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                          {platform.avgSentiment > 0 ? '+' : ''}{platform.avgSentiment}
                        </span>
                      </td>
                      <td className="py-4 text-gray-300">{platform.responseTime}</td>
                      <td className="py-4">
                        <div className="flex items-center space-x-2">
                          <div className="w-16 h-2 bg-gray-700 rounded-full overflow-hidden">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${platform.satisfaction}%` }}
                              transition={{ duration: 1, delay: index * 0.2 }}
                              className={`h-full rounded-full ${
                                platform.satisfaction >= 80 ? 'bg-green-500' :
                                platform.satisfaction >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                              }`}
                            />
                          </div>
                          <span className="text-white text-sm font-medium">{platform.satisfaction}%</span>
                        </div>
                      </td>
                      <td className="py-4">
                        <motion.span 
                          whileHover={{ scale: 1.1 }}
                          className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-500/20 text-green-400 border border-green-500/30"
                        >
                          Active
                        </motion.span>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-12">
              <motion.div
                animate={{ rotateY: 360 }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              >
                <ChartBarIcon className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              </motion.div>
              <p className="text-gray-400">Connect platforms to see 3D performance analytics</p>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default AnalyticsDashboard;