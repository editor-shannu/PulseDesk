import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyBjuoOiiiJfYCMvrBqzMRaMM7N0a_Dl3I0",
  authDomain: "pulsedesk-3672a.firebaseapp.com",
  projectId: "pulsedesk-3672a",
  storageBucket: "pulsedesk-3672a.appspot.com",
  messagingSenderId: "896429481219",
  appId: "1:896429481219:web:941a2e42c556847b221d36",
  measurementId: "G-8BNGZXSKGW"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

export default app;